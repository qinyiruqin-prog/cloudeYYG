import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { 
  FALLBACK_PROFILES, 
  COMPLEMENTARY_PAIRS, 
  GENERAL_OUTRAGEOUS_DEMANDS, 
  SERIOUS_DEMANDS, 
  OCCUPATIONS, 
  PERSONALITY_TAGS,
  FAMILY_ASSETS,
  HEALTH_CONDITIONS,
  PARENT_INFOS,
  BRIDE_PRICE_DEMANDS
} from "./src/data/demandsData.js";

const app = express();
const PORT = 3000;

app.use(express.json());

// Helper function to pick random element from array
function getRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

// Helper to generate 2 guests with ~50% chance of complementary demands
function generateGuestPair(randomUsers?: Array<{ picture: { large: string }; gender: string; dob: { age: number } }>) {
  const isComplementaryPair = Math.random() < 0.5;
  const pickedPair = isComplementaryPair ? getRandom(COMPLEMENTARY_PAIRS) : null;

  // Chinese Surnames & Given Names
  const surnames = ["赵", "钱", "孙", "李", "周", "吴", "郑", "王", "冯", "陈", "褚", "卫", "蒋", "沈", "韩", "杨", "朱", "秦", "尤", "许"];
  const maleNames = ["伟", "强", "磊", "洋", "勇", "军", "平", "保国", "建国", "子轩", "浩然", "宇轩", "奕辰"];
  const femaleNames = ["芳", "娜", "敏", "静", "秀英", "丽", "艳", "梓涵", "语嫣", "诗琪", "欣怡", "雨婷"];

  const g1IsMale = randomUsers?.[0]?.gender ? randomUsers[0].gender === 'male' : Math.random() > 0.5;
  const g2IsMale = randomUsers?.[1]?.gender ? randomUsers[1].gender === 'male' : !g1IsMale;

  const name1 = randomUsers 
    ? (getRandom(surnames) + getRandom(g1IsMale ? maleNames : femaleNames))
    : getRandom(FALLBACK_PROFILES).name;

  let name2 = randomUsers 
    ? (getRandom(surnames) + getRandom(g2IsMale ? maleNames : femaleNames))
    : getRandom(FALLBACK_PROFILES).name;
  
  if (name2 === name1) name2 += "二世";

  const avatar1 = randomUsers?.[0]?.picture?.large || getRandom(FALLBACK_PROFILES).avatar;
  const avatar2 = randomUsers?.[1]?.picture?.large || getRandom(FALLBACK_PROFILES).avatar;

  const age1 = randomUsers?.[0]?.dob?.age || Math.floor(Math.random() * 12) + 20;
  const age2 = randomUsers?.[1]?.dob?.age || Math.floor(Math.random() * 12) + 20;

  // Demands logic
  let demand1 = "";
  let keywords1: string[] = [];
  let demand2 = "";
  let keywords2: string[] = [];

  if (pickedPair) {
    demand1 = pickedPair.demandA;
    keywords1 = pickedPair.keywordsA;
    demand2 = pickedPair.demandB;
    keywords2 = pickedPair.keywordsB;
  } else {
    demand1 = getRandom(GENERAL_OUTRAGEOUS_DEMANDS);
    keywords1 = ["奇葩要求", "个人癖好"];
    demand2 = getRandom(GENERAL_OUTRAGEOUS_DEMANDS);
    keywords2 = ["脑洞大开", "特别偏好"];
  }

  const guest1 = {
    id: `g1_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
    name: name1,
    gender: g1IsMale ? ('male' as const) : ('female' as const),
    age: age1 > 50 || age1 < 18 ? Math.floor(Math.random() * 10) + 21 : age1,
    avatar: avatar1,
    occupation: getRandom(OCCUPATIONS),
    personality: [getRandom(PERSONALITY_TAGS), getRandom(PERSONALITY_TAGS)],
    seriousDemand: getRandom(SERIOUS_DEMANDS),
    outrageousDemand: demand1,
    demandKeywords: keywords1,
    micNumber: 1 as const,
    isOnline: true,
    familyAsset: getRandom(FAMILY_ASSETS),
    healthCondition: getRandom(HEALTH_CONDITIONS),
    parentInfo: getRandom(PARENT_INFOS),
    bridePriceDemand: getRandom(BRIDE_PRICE_DEMANDS),
    connectionStatus: 'connected' as const
  };

  const guest2 = {
    id: `g2_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
    name: name2,
    gender: g2IsMale ? ('male' as const) : ('female' as const),
    age: age2 > 50 || age2 < 18 ? Math.floor(Math.random() * 10) + 22 : age2,
    avatar: avatar2,
    occupation: getRandom(OCCUPATIONS),
    personality: [getRandom(PERSONALITY_TAGS), getRandom(PERSONALITY_TAGS)],
    seriousDemand: getRandom(SERIOUS_DEMANDS),
    outrageousDemand: demand2,
    demandKeywords: keywords2,
    micNumber: 2 as const,
    isOnline: true,
    familyAsset: getRandom(FAMILY_ASSETS),
    healthCondition: getRandom(HEALTH_CONDITIONS),
    parentInfo: getRandom(PARENT_INFOS),
    bridePriceDemand: getRandom(BRIDE_PRICE_DEMANDS),
    connectionStatus: 'connected' as const
  };

  return [guest1, guest2];
}

// API endpoint to fetch 2 random user guests
app.get("/api/guests", async (req, res) => {
  try {
    // Call randomuser.me API with 3-second timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);

    const apiRes = await fetch("https://randomuser.me/api/?results=2&inc=gender,picture,dob,name", {
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    if (apiRes.ok) {
      const data = await apiRes.json();
      if (data.results && data.results.length === 2) {
        const pair = generateGuestPair(data.results);
        return res.json({ success: true, source: "randomuser.me", guests: pair });
      }
    }
    throw new Error("Failed to fetch valid randomuser data");
  } catch (err) {
    console.warn("randomuser.me API fetch failed or timed out, using fallback profiles pool:", (err as Error).message);
    // Hardcoded Fallback Pool
    const p1 = getRandom(FALLBACK_PROFILES);
    let p2 = getRandom(FALLBACK_PROFILES);
    while (p2.name === p1.name) {
      p2 = getRandom(FALLBACK_PROFILES);
    }

    // ~50% chance to overwrite with complementary pair for high gameplay fun
    const isComplementary = Math.random() < 0.5;
    if (isComplementary) {
      const pair = getRandom(COMPLEMENTARY_PAIRS);
      p1.outrageousDemand = pair.demandA;
      p1.demandKeywords = pair.keywordsA;
      p2.outrageousDemand = pair.demandB;
      p2.demandKeywords = pair.keywordsB;
    }

    const guest1 = {
      familyAsset: getRandom(FAMILY_ASSETS),
      healthCondition: getRandom(HEALTH_CONDITIONS),
      parentInfo: getRandom(PARENT_INFOS),
      bridePriceDemand: getRandom(BRIDE_PRICE_DEMANDS),
      connectionStatus: 'connected' as const,
      ...p1,
      id: `fallback1_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      micNumber: 1 as const,
      isOnline: true
    };
    const guest2 = {
      familyAsset: getRandom(FAMILY_ASSETS),
      healthCondition: getRandom(HEALTH_CONDITIONS),
      parentInfo: getRandom(PARENT_INFOS),
      bridePriceDemand: getRandom(BRIDE_PRICE_DEMANDS),
      connectionStatus: 'connected' as const,
      ...p2,
      id: `fallback2_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      micNumber: 2 as const,
      isOnline: true
    };

    return res.json({ success: true, source: "fallback_pool", guests: [guest1, guest2] });
  }
});

// API Test Connection Endpoint
app.post("/api/test-connection", async (req, res) => {
  const start = Date.now();
  try {
    const { apiKey, baseUrl, model } = req.body || {};
    const keyToUse = apiKey || process.env.GEMINI_API_KEY;
    const modelToUse = model || "gemini-2.5-flash";

    if (!keyToUse) {
      return res.status(400).json({
        success: false,
        error: "未提供 API Key，且服务端未找到 GEMINI_API_KEY 环境变量。"
      });
    }

    const clientOptions: any = { apiKey: keyToUse };
    if (baseUrl && typeof baseUrl === 'string' && baseUrl.trim() !== '') {
      clientOptions.httpOptions = { baseUrl: baseUrl.trim() };
    }

    const ai = new GoogleGenAI(clientOptions);
    const response = await ai.models.generateContent({
      model: modelToUse,
      contents: "请用一句话回答：羊月老直播相亲局AI控场模组连接状态是否正常？",
    });

    const latencyMs = Date.now() - start;
    const sampleResponse = response.text || "【羊月老AI控场中枢】中转站代理通信正常，模组已就绪！";

    return res.json({
      success: true,
      latencyMs,
      model: modelToUse,
      sampleResponse,
      message: `API / 中转站连接成功！使用模型 ${modelToUse}${baseUrl ? ` (中转节点: ${baseUrl})` : ''}，耗时 ${latencyMs}ms`
    });
  } catch (err) {
    const latencyMs = Date.now() - start;
    console.error("Gemini API connection test error:", err);
    return res.status(500).json({
      success: false,
      latencyMs,
      error: "Gemini API / 中转站测试失败: " + ((err as Error).message || "未知错误")
    });
  }
});

// API Model Extraction Endpoint
app.post("/api/models", async (req, res) => {
  try {
    const { apiKey, baseUrl } = req.body || {};
    const keyToUse = apiKey || process.env.GEMINI_API_KEY;

    // Extracted model catalog with latency & capability metadata
    const extractedModels = [
      { id: 'gemini-2.5-flash', name: 'Gemini 2.5 Flash', status: 'Active', speed: '⚡ 极速', desc: '最佳平衡，响应极快，推荐日常连麦分析使用', recommended: true },
      { id: 'gemini-2.5-pro', name: 'Gemini 2.5 Pro', status: 'Active', speed: '🧠 高智商', desc: '深度推理模型，精准分析爆款奇葩要求与天作之合匹配度' },
      { id: 'gemini-2.0-flash', name: 'Gemini 2.0 Flash', status: 'Active', speed: '🚀 超低时延', desc: '毫秒级响应，适合实时直播间控场及观众弹幕互动' },
      { id: 'gemini-1.5-flash', name: 'Gemini 1.5 Flash', status: 'Active', speed: '标准', desc: '经典稳定版本模型' },
    ];

    if (keyToUse) {
      try {
        const clientOptions: any = { apiKey: keyToUse };
        if (baseUrl && typeof baseUrl === 'string' && baseUrl.trim() !== '') {
          clientOptions.httpOptions = { baseUrl: baseUrl.trim() };
        }
        const ai = new GoogleGenAI(clientOptions);
        // Attempt to verify key or list models if supported
        const list = await ai.models.list();
        if (list && Array.isArray(list)) {
          console.log("Successfully extracted live models from Gemini API / Relay Station:", list.length);
        }
      } catch (e) {
        console.warn("Model list query fallback:", (e as Error).message);
      }
    }

    return res.json({
      success: true,
      models: extractedModels,
      hasApiKey: !!keyToUse,
      relayUrl: baseUrl || 'Default Official Node'
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      error: (err as Error).message
    });
  }
});

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", app: "羊月老(直播间连麦版)" });
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`羊月老 server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
