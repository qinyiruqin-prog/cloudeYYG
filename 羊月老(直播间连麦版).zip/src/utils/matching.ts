import { Guest, MatchResult } from '../types';
import { COMPLEMENTARY_PAIRS, RED_MAIDEN_SUCCESS_COMMENTS, RED_MAIDEN_FAIL_COMMENTS } from '../data/demandsData';

export function evaluateMatch(guest1: Guest, guest2: Guest): MatchResult {
  let isMatch = false;
  let score = 30;
  let matchedKeywords: string[] = [];
  let reason = "";

  // 1. Check if they hit an explicit complementary pair
  const pair = COMPLEMENTARY_PAIRS.find(p => 
    (guest1.outrageousDemand.includes(p.demandA) || p.keywordsA.some(k => guest1.demandKeywords.includes(k))) &&
    (guest2.outrageousDemand.includes(p.demandB) || p.keywordsB.some(k => guest2.demandKeywords.includes(k)))
  ) || COMPLEMENTARY_PAIRS.find(p => 
    (guest2.outrageousDemand.includes(p.demandA) || p.keywordsA.some(k => guest1.demandKeywords.includes(k))) &&
    (guest1.outrageousDemand.includes(p.demandB) || p.keywordsB.some(k => guest2.demandKeywords.includes(k)))
  );

  if (pair) {
    isMatch = true;
    score = Math.floor(Math.random() * 15) + 85; // 85-99
    matchedKeywords = [...new Set([...pair.keywordsA, ...pair.keywordsB])];
    reason = pair.reason;
  } else {
    // 2. Check keyword overlaps directly
    const commonKeywords = guest1.demandKeywords.filter(k => guest2.demandKeywords.includes(k));
    if (commonKeywords.length > 0) {
      isMatch = true;
      score = Math.floor(Math.random() * 15) + 80;
      matchedKeywords = commonKeywords;
      reason = `两位嘉宾在【${commonKeywords.join(' / ')}】等要求上高度吻合！`;
    } else {
      // 3. Heuristic keyword checks for fun
      const text1 = guest1.outrageousDemand + guest1.personality.join('');
      const text2 = guest2.outrageousDemand + guest2.personality.join('');
      
      const funPairs = [
        ['做饭', '洗碗'], ['社恐', '社牛'], ['游戏', '电竞'], ['养羊', '草原'],
        ['电脑', 'IT'], ['零食', '扫尾'], ['盲盒', '收藏'], ['算命', '占卜'],
        ['私房钱', '侦探'], ['睡前故事', '声优']
      ];

      for (const [k1, k2] of funPairs) {
        if ((text1.includes(k1) && text2.includes(k2)) || (text1.includes(k2) && text2.includes(k1))) {
          isMatch = true;
          score = Math.floor(Math.random() * 15) + 82;
          matchedKeywords = [k1, k2];
          reason = `隐藏默契！${guest1.name}与${guest2.name}一个爱${k1}，一个擅长${k2}！`;
          break;
        }
      }
    }
  }

  // Choose commentary line
  let commentary = "";
  if (isMatch) {
    const randomHostLine = RED_MAIDEN_SUCCESS_COMMENTS[Math.floor(Math.random() * RED_MAIDEN_SUCCESS_COMMENTS.length)];
    commentary = `${randomHostLine} ${reason || '离谱要求竟然神奇互补！'}`;
  } else {
    score = Math.floor(Math.random() * 30) + 15; // 15-44
    const randomHostLine = RED_MAIDEN_FAIL_COMMENTS[Math.floor(Math.random() * RED_MAIDEN_FAIL_COMMENTS.length)];
    commentary = `${randomHostLine} ${guest1.name}想要【${guest1.demandKeywords[0] || '奇葩要求'}】，而${guest2.name}则是【${guest2.demandKeywords[0] || '完全不同'}】，简直对不上眼！`;
  }

  return {
    id: `match_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
    timestamp: new Date(),
    guest1,
    guest2,
    isMatch,
    score,
    matchedKeywords,
    commentary,
    meritDelta: isMatch ? 1 : -1
  };
}
