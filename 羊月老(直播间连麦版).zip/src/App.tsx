import React, { useState, useEffect, useCallback } from 'react';
import { LiveHeader } from './components/LiveHeader';
import { GuestCard } from './components/GuestCard';
import { MatchControls } from './components/MatchControls';
import { MatchResultOverlay } from './components/MatchResultOverlay';
import { DanmakuCanvas } from './components/DanmakuCanvas';
import { GiftBar } from './components/GiftBar';
import { CelebrationEffects } from './components/CelebrationEffects';
import { HistoryDrawer } from './components/HistoryDrawer';
import { PwaInstallModal } from './components/PwaInstallModal';
import { StreamerCenterStage } from './components/StreamerCenterStage';
import { LiveChatRoom } from './components/LiveChatRoom';
import { ApiConfigModal } from './components/ApiConfigModal';
import { Guest, MatchResult, GiftItem, StreamerStats, AudiencePoll } from './types';
import { evaluateMatch } from './utils/matching';
import { soundManager } from './utils/audio';

export default function App() {
  const [guests, setGuests] = useState<[Guest, Guest] | null>(null);
  const [isLoadingGuests, setIsLoadingGuests] = useState<boolean>(true);
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [matchResult, setMatchResult] = useState<MatchResult | null>(null);

  // Streamer Stats
  const [streamerStats, setStreamerStats] = useState<StreamerStats>({
    level: 5,
    title: '羊村金牌红娘',
    pairedCount: 0,
    todayGoal: 10,
    coinsEarned: 2580,
    liveTimeSeconds: 120,
  });

  // Audience Poll State
  const [poll, setPoll] = useState<AudiencePoll>({
    matchVotes: 18,
    noMatchVotes: 5,
    totalVotes: 23,
  });

  // Merit Points State
  const [meritPoints, setMeritPoints] = useState<number>(() => {
    const saved = localStorage.getItem('yang_yuelao_merit');
    return saved ? parseInt(saved, 10) : 0;
  });

  // History Log
  const [history, setHistory] = useState<MatchResult[]>([]);

  // Toggles & Modes
  const [autoMode, setAutoMode] = useState<boolean>(false);
  const [isAutoAdvancing, setIsAutoAdvancing] = useState<boolean>(true);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Modals & Effects
  const [danmakuMsg, setDanmakuMsg] = useState<string | null>(null);
  const [celebrationMilestone, setCelebrationMilestone] = useState<number | null>(null);
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [isInstallOpen, setIsInstallOpen] = useState<boolean>(false);
  const [isApiConfigOpen, setIsApiConfigOpen] = useState<boolean>(false);
  const [selectedModel, setSelectedModel] = useState<string>('gemini-2.5-flash');

  // Fetch Next Guest Pair from /api/guests
  const fetchGuestPair = useCallback(async () => {
    setIsLoadingGuests(true);
    setMatchResult(null);

    try {
      const res = await fetch('/api/guests');
      const data = await res.json();
      if (data.success && data.guests && data.guests.length === 2) {
        // Add rich live speech to guests upon connecting one by one
        const guestA = {
          ...data.guests[0],
          currentSpeech: `羊月老好！我今年${data.guests[0].age}岁，家境【${data.guests[0].familyAsset || 'A9豪门'}】，已向父母如实报备个人及择偶情况！期望对方【${data.guests[0].bridePriceDemand || '高价彩礼匹配'}】！`
        };
        const guestB = {
          ...data.guests[1],
          currentSpeech: `主播好！我${data.guests[1].age}岁，身体表里指标【${data.guests[1].healthCondition || '十分健康'}】，父母也支持我来连麦！择偶爆款要求是【${data.guests[1].outrageousDemand}】！`
        };

        setGuests([guestA, guestB]);
        soundManager.playMicConnect();

        // Reset audience poll for new pair
        const randomMatch = Math.floor(Math.random() * 20) + 15;
        const randomNoMatch = Math.floor(Math.random() * 8) + 2;
        setPoll({
          matchVotes: randomMatch,
          noMatchVotes: randomNoMatch,
          totalVotes: randomMatch + randomNoMatch,
        });
      } else {
        throw new Error('Invalid guest format');
      }
    } catch (err) {
      console.error('Failed to fetch guests:', err);
    } finally {
      setIsLoadingGuests(false);
    }
  }, []);

  // Initial load
  useEffect(() => {
    fetchGuestPair();
  }, [fetchGuestPair]);

  // Save merit points
  useEffect(() => {
    localStorage.setItem('yang_yuelao_merit', meritPoints.toString());
  }, [meritPoints]);

  // Handle Streamer Soundboard triggers
  const handlePlaySfx = (type: 'goat' | 'applause' | 'gavel' | 'alarm') => {
    if (type === 'goat') soundManager.playGoat();
    else if (type === 'applause') soundManager.playApplause();
    else if (type === 'gavel') soundManager.playGavel();
    else if (type === 'alarm') soundManager.playAlarm();
  };

  // Handle Streamer Ask Guest
  const handleStreamerAsk = (targetMic: 1 | 2) => {
    if (!guests) return;
    soundManager.playGoat();
    setGuests((prev) => {
      if (!prev) return prev;
      const updated = [...prev] as [Guest, Guest];
      const idx = targetMic - 1;
      const g = updated[idx];
      updated[idx] = {
        ...g,
        currentSpeech: `主播我补充下：我今年${g.age}岁，原生身家【${g.familyAsset}】，已向父母全盘报备！【${g.bridePriceDemand}】是认真考虑过的！`,
      };
      return updated;
    });
  };

  // Handle User Vote in Poll
  const handleUserVote = (type: 'match' | 'noMatch') => {
    setPoll((prev) => ({
      ...prev,
      matchVotes: type === 'match' ? prev.matchVotes + 1 : prev.matchVotes,
      noMatchVotes: type === 'noMatch' ? prev.noMatchVotes + 1 : prev.noMatchVotes,
      totalVotes: prev.totalVotes + 1,
    }));
  };

  // Handle "牵红线" Match Evaluation
  const handleMatch = () => {
    if (!guests || isEvaluating || isLoadingGuests) return;

    soundManager.playGavel();
    setIsEvaluating(true);
    const result = evaluateMatch(guests[0], guests[1]);

    // Update merit points & streamer stats
    setMeritPoints((prev) => {
      const newPoints = Math.max(0, prev + result.meritDelta);

      if ((prev < 5 && newPoints >= 5) || (prev < 10 && newPoints >= 10)) {
        setCelebrationMilestone(newPoints >= 10 ? 10 : 5);
      }

      return newPoints;
    });

    setStreamerStats((prev) => ({
      ...prev,
      pairedCount: prev.pairedCount + (result.isMatch ? 1 : 0),
      coinsEarned: prev.coinsEarned + (result.isMatch ? 100 : 20),
    }));

    // Play audio
    if (result.isMatch) {
      soundManager.playSuccess();
    } else {
      soundManager.playFail();
    }

    setMatchResult(result);
    setHistory((prev) => [result, ...prev.slice(0, 15)]);
    setIsEvaluating(false);

    // Broadcast danmaku message
    if (result.isMatch) {
      setDanmakuMsg(`🎉 喜讯：主播【羊月老】拍案促成【${result.guest1.name}】与【${result.guest2.name}】姻缘！`);
    }
  };

  // Next Pair Action (1.5s auto advance or manual click)
  const handleNextPair = useCallback(() => {
    setMatchResult(null);
    fetchGuestPair();
  }, [fetchGuestPair]);

  // Auto Mode loop if enabled
  useEffect(() => {
    if (autoMode && !matchResult && !isLoadingGuests && guests && !isEvaluating) {
      const timer = setTimeout(() => {
        handleMatch();
      }, 1200);
      return () => clearTimeout(timer);
    }
  }, [autoMode, matchResult, isLoadingGuests, guests, isEvaluating]);

  // Send Gift Handler
  const handleSendGift = (gift: GiftItem) => {
    soundManager.playGift();
    setStreamerStats((prev) => ({
      ...prev,
      coinsEarned: prev.coinsEarned + gift.price,
    }));
    setDanmakuMsg(`🎁 榜一大哥在直播间送出了【${gift.name} ${gift.icon}】！主播说了一声谢谢老铁！`);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between font-sans relative overflow-x-hidden">
      {/* Background Live Stream Stage Design */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-red-600/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-emerald-600/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1000ms' }} />
      </div>

      {/* Real-time Audience Danmaku Canvas */}
      <DanmakuCanvas customMessage={danmakuMsg} />

      {/* Top Header */}
      <LiveHeader
        meritPoints={meritPoints}
        onOpenHistory={() => setIsHistoryOpen(true)}
        onOpenInstall={() => setIsInstallOpen(true)}
        onOpenApiConfig={() => setIsApiConfigOpen(true)}
        soundEnabled={soundEnabled}
        setSoundEnabled={setSoundEnabled}
      />

      {/* Main Live Stage: Guest Cards + Streamer Stage + Live Chat */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-3 py-3 sm:px-6 flex flex-col justify-center z-10 gap-4">
        {/* Streamer Center Control Hub & Speech Bar */}
        <StreamerCenterStage
          stats={streamerStats}
          guest1={guests ? guests[0] : null}
          guest2={guests ? guests[1] : null}
          onStreamerAsk={handleStreamerAsk}
          onPlaySfx={handlePlaySfx}
        />

        {/* Dual Guest Cards Stage */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-stretch">
          {guests ? (
            <>
              <GuestCard guest={guests[0]} position="left" isLoading={isLoadingGuests} />
              <GuestCard guest={guests[1]} position="right" isLoading={isLoadingGuests} />
            </>
          ) : (
            <>
              <GuestCard
                guest={{
                  id: 'temp1',
                  name: '嘉宾加载中',
                  gender: 'female',
                  age: 22,
                  avatar: '',
                  occupation: '',
                  personality: [],
                  seriousDemand: '',
                  outrageousDemand: '',
                  demandKeywords: [],
                  micNumber: 1,
                  isOnline: true,
                }}
                position="left"
                isLoading={true}
              />
              <GuestCard
                guest={{
                  id: 'temp2',
                  name: '嘉宾加载中',
                  gender: 'male',
                  age: 25,
                  avatar: '',
                  occupation: '',
                  personality: [],
                  seriousDemand: '',
                  outrageousDemand: '',
                  demandKeywords: [],
                  micNumber: 2,
                  isOnline: true,
                }}
                position="right"
                isLoading={true}
              />
            </>
          )}
        </div>

        {/* Live Audience Chat Room & Voting Poll */}
        <LiveChatRoom
          guest1={guests ? guests[0] : null}
          guest2={guests ? guests[1] : null}
          poll={poll}
          onUserVote={handleUserVote}
        />

        {/* Action Controls Bar */}
        <MatchControls
          onMatch={handleMatch}
          onRefresh={fetchGuestPair}
          isEvaluating={isEvaluating}
          isLoadingNew={isLoadingGuests}
          autoMode={autoMode}
          setAutoMode={setAutoMode}
        />
      </main>

      {/* Bottom Footer Bar */}
      <footer className="z-10 bg-slate-900/80 border-t border-slate-800 py-3 px-4">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="font-bold text-amber-400">羊月老直播相亲局</span>
            <span>· 你是主播，拍案促姻缘，带起直播间狂欢！</span>
          </div>

          <div className="flex items-center gap-3">
            <GiftBar onSendGift={handleSendGift} />
          </div>
        </div>
      </footer>

      {/* Result Popover (1.5s Auto Advance) */}
      <MatchResultOverlay
        result={matchResult}
        onNext={handleNextPair}
        isAutoAdvancing={isAutoAdvancing}
        setIsAutoAdvancing={setIsAutoAdvancing}
      />

      {/* Milestone Celebrations (5 points petals, 10 points red envelopes) */}
      <CelebrationEffects
        milestone={celebrationMilestone}
        onClose={() => setCelebrationMilestone(null)}
      />

      {/* History Drawer */}
      <HistoryDrawer
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        history={history}
      />

      {/* Install PWA Guide Modal */}
      <PwaInstallModal
        isOpen={isInstallOpen}
        onClose={() => setIsInstallOpen(false)}
      />

      {/* AI API & Model Extraction / Test Connection Modal */}
      <ApiConfigModal
        isOpen={isApiConfigOpen}
        onClose={() => setIsApiConfigOpen(false)}
        selectedModel={selectedModel}
        setSelectedModel={setSelectedModel}
      />
    </div>
  );
}
