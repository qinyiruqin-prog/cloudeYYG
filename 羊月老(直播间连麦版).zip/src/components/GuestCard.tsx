import React from 'react';
import { motion } from 'motion/react';
import { Mic, AlertCircle, Heart, Sparkles, UserCheck, ShieldCheck } from 'lucide-react';
import { Guest } from '../types';

interface GuestCardProps {
  guest: Guest;
  position: 'left' | 'right';
  isLoading?: boolean;
}

export const GuestCard: React.FC<GuestCardProps> = ({ guest, position, isLoading }) => {
  const isMic1 = guest.micNumber === 1;

  if (isLoading) {
    return (
      <div className="w-full bg-slate-800/80 rounded-2xl border-2 border-slate-700/80 p-4 sm:p-5 flex flex-col items-center justify-center min-h-[360px] animate-pulse">
        <div className="w-20 h-20 rounded-full bg-slate-700 mb-3" />
        <div className="h-4 w-28 bg-slate-700 rounded mb-2" />
        <div className="h-3 w-16 bg-slate-700/60 rounded mb-4" />
        <div className="w-full space-y-2">
          <div className="h-12 bg-slate-700/40 rounded-xl" />
          <div className="h-20 bg-slate-700/60 rounded-xl" />
        </div>
        <p className="text-xs text-amber-400/80 mt-4 animate-bounce">正在接入{guest.micNumber}号麦嘉宾...</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, x: position === 'left' ? -30 : 30, scale: 0.95 }}
      animate={{ opacity: 1, x: 0, scale: 1 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="w-full bg-gradient-to-b from-slate-800 via-slate-850 to-slate-900 rounded-2xl border-2 border-amber-500/30 hover:border-amber-500/60 p-4 sm:p-5 shadow-xl relative overflow-hidden flex flex-col justify-between"
    >
      {/* Background Decorative Pattern */}
      <div className="absolute -right-8 -top-8 w-24 h-24 bg-red-600/10 rounded-full blur-xl pointer-events-none" />
      <div className="absolute -left-8 -bottom-8 w-24 h-24 bg-emerald-600/10 rounded-full blur-xl pointer-events-none" />

      {/* Top Bar: Mic Badge & Online Status */}
      <div className="flex items-center justify-between mb-3 z-10">
        <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-bold ${
          isMic1 
            ? 'bg-red-950/80 text-red-300 border-red-500/50' 
            : 'bg-emerald-950/80 text-emerald-300 border-emerald-500/50'
        }`}>
          <Mic className="w-3.5 h-3.5 animate-pulse" />
          <span>{guest.micNumber}号麦</span>
          <div className="flex gap-0.5 items-end h-3 ml-1">
            <span className="w-0.5 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
            <span className="w-0.5 h-3 bg-current rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
            <span className="w-0.5 h-1.5 bg-current rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
          </div>
        </div>

        <div className="flex items-center gap-2">
          {guest.currentSpeech && (
            <span className="text-[10px] text-amber-300 bg-slate-900/90 px-2 py-0.5 rounded-full border border-amber-500/40 animate-pulse">
              💬 连麦发言中
            </span>
          )}
          <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded-full border border-emerald-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            已连麦
          </span>
        </div>
      </div>

      {/* Guest Live Voice Speech Bubble */}
      {guest.currentSpeech && (
        <motion.div
          initial={{ opacity: 0, y: -10, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          className="mb-3 bg-amber-400 text-slate-950 p-2.5 rounded-2xl border-2 border-white shadow-xl relative z-20 font-bold text-xs leading-snug"
        >
          <div className="flex items-center gap-1 text-[10px] text-slate-900 mb-0.5 font-black">
            <span>🗣️ {guest.name} 连麦现场发言：</span>
          </div>
          “{guest.currentSpeech}”
        </motion.div>
      )}

      {/* Profile Header: Avatar, Name, Age, Occupation */}
      <div className="flex flex-col items-center text-center mb-3 z-10">
        <div className="relative group mb-2">
          {/* Avatar Ring */}
          <div className={`p-1 rounded-full bg-gradient-to-tr ${
            isMic1 ? 'from-red-500 via-amber-400 to-red-600' : 'from-emerald-500 via-teal-300 to-emerald-600'
          } shadow-md`}>
            <img
              src={guest.avatar}
              alt={guest.name}
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-full object-cover border-2 border-slate-900 shadow-inner"
              onError={(e) => {
                // Fallback avatar if link fails
                (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/bottts/svg?seed=${guest.name}`;
              }}
            />
          </div>
          <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-slate-900/90 text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-amber-500/40 flex items-center gap-1">
            <span>{guest.gender === 'male' ? '♂️' : '♀️'}</span>
            <span>{guest.age}岁</span>
          </div>
        </div>

        <h3 className="text-lg sm:text-xl font-black text-slate-100 flex items-center gap-1">
          {guest.name}
        </h3>
        <p className="text-xs text-amber-300/90 font-medium bg-slate-900/60 px-2.5 py-0.5 rounded-full border border-slate-700 mt-1">
          💼 {guest.occupation}
        </p>

        {/* Personality Tags */}
        <div className="flex flex-wrap gap-1 justify-center mt-2">
          {guest.personality.map((tag, idx) => (
            <span
              key={idx}
              className="text-[11px] px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700/80"
            >
              #{tag}
            </span>
          ))}
        </div>
      </div>

      {/* Demands & Detailed Background Section */}
      <div className="space-y-2 text-xs z-10">
        {/* Basic & Family Assets Row (A9/A9+1) */}
        <div className="grid grid-cols-2 gap-1.5 bg-slate-900/80 rounded-xl p-2 border border-amber-500/30">
          <div className="flex flex-col">
            <span className="text-[10px] text-amber-400 font-bold">💰 原生家庭身家：</span>
            <span className="text-[11px] text-slate-100 font-bold font-mono">{guest.familyAsset || 'A8 千万身家'}</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] text-emerald-400 font-bold">🩺 表里身体状况：</span>
            <span className="text-[10px] text-slate-200 line-clamp-1">{guest.healthCondition || '内在五脏健康 / 外在气色充沛'}</span>
          </div>
        </div>

        {/* Parents Status & High Price/Dowry Expectations */}
        <div className="bg-slate-900/70 rounded-xl p-2 border border-slate-700/80 space-y-1">
          <div className="flex items-start gap-1">
            <span className="text-[10px] text-slate-400 font-bold whitespace-nowrap">👪 父母告知：</span>
            <span className="text-[10px] text-slate-200 leading-tight">{guest.parentInfo || '已向父母全盘报备基本信息及要求'}</span>
          </div>
          <div className="flex items-start gap-1 pt-1 border-t border-slate-800">
            <span className="text-[10px] text-amber-300 font-bold whitespace-nowrap">💎 对方身价/彩礼期望：</span>
            <span className="text-[10px] text-amber-200 font-bold leading-tight">{guest.bridePriceDemand || '期望对方家境相当/高价彩礼'}</span>
          </div>
        </div>

        {/* Serious Demand */}
        <div className="bg-slate-900/70 rounded-xl p-2 border border-slate-700/80">
          <div className="text-[10px] font-bold text-slate-400 flex items-center gap-1 mb-0.5">
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            <span>正经择偶要求</span>
          </div>
          <p className="text-slate-200 leading-snug font-normal text-[11px]">
            {guest.seriousDemand}
          </p>
        </div>

        {/* Outrageous Demand (HL) */}
        <div className="bg-gradient-to-r from-amber-950/80 via-red-950/70 to-amber-950/80 rounded-xl p-2.5 border-2 border-amber-500/60 shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 bg-amber-500 text-slate-950 text-[9px] font-black px-1.5 py-0.5 rounded-bl-lg flex items-center gap-0.5">
            <Sparkles className="w-2.5 h-2.5" /> 离谱要求
          </div>

          <div className="text-[10px] font-bold text-amber-300 flex items-center gap-1 mb-0.5">
            <AlertCircle className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span>🔥 爆款离谱要求：</span>
          </div>
          <p className="text-amber-100 font-bold text-xs sm:text-sm leading-snug tracking-wide">
            “{guest.outrageousDemand}”
          </p>

          {/* Keywords tags */}
          <div className="flex flex-wrap gap-1 mt-1.5 pt-1.5 border-t border-amber-500/20">
            {guest.demandKeywords.map((kw, i) => (
              <span key={i} className="bg-amber-500/20 text-amber-200 text-[9px] px-1.5 py-0.2 rounded border border-amber-500/30">
                #{kw}
              </span>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
};
