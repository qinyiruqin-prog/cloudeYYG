import React, { useEffect, useState } from 'react';
import { Download, Smartphone, Share, PlusSquare, CheckCircle, X } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

interface PwaInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PwaInstallModal: React.FC<PwaInstallModalProps> = ({ isOpen, onClose }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener('beforeinstallprompt', handler);

    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
      }
      setDeferredPrompt(null);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-slate-900 border-2 border-amber-500/50 rounded-3xl p-6 max-w-md w-full shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-5">
          <div className="w-14 h-14 mx-auto mb-2 rounded-2xl bg-gradient-to-tr from-red-600 to-amber-500 p-0.5 shadow-lg">
            <div className="w-full h-full bg-slate-950 rounded-2xl flex items-center justify-center text-2xl">
              🐑
            </div>
          </div>
          <h2 className="text-xl font-black text-slate-100">安装【羊月老】到手机主页</h2>
          <p className="text-xs text-slate-400 mt-1">像原生App一样随时连麦相亲，体验更顺畅！</p>
        </div>

        {isInstalled ? (
          <div className="bg-emerald-950/60 border border-emerald-500/40 rounded-2xl p-4 text-center text-emerald-300 text-xs font-bold flex items-center justify-center gap-2">
            <CheckCircle className="w-5 h-5 text-emerald-400" />
            <span>羊月老已成功安装到主页！</span>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Standard PWA Button */}
            {deferredPrompt && (
              <button
                onClick={handleInstallClick}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-sm shadow-lg shadow-emerald-900/40 flex items-center justify-center gap-2 transition active:scale-95"
              >
                <Download className="w-5 h-5" />
                <span>一键直接安装到桌面</span>
              </button>
            )}

            {/* iOS Guide */}
            <div className="bg-slate-850 rounded-2xl p-3.5 border border-slate-700/80 space-y-2 text-xs text-slate-200">
              <div className="font-bold text-amber-300 flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-amber-400" />
                <span>iPhone / iOS Safari 浏览器：</span>
              </div>
              <ol className="list-decimal list-inside space-y-1 text-slate-300 text-[11px] leading-relaxed">
                <li>点击 Safari 浏览器底部的 <Share className="w-3.5 h-3.5 inline text-sky-400 mx-0.5" /> 【分享】按钮</li>
                <li>向上滑动菜单，找到并选择 <PlusSquare className="w-3.5 h-3.5 inline text-amber-400 mx-0.5" /> 【添加到主屏幕】</li>
                <li>点击右上角【添加】，即可在主页直接打开游戏！</li>
              </ol>
            </div>

            {/* Android / Other Guide */}
            <div className="bg-slate-850 rounded-2xl p-3.5 border border-slate-700/80 space-y-2 text-xs text-slate-200">
              <div className="font-bold text-emerald-300 flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <span>Android / Chrome 微信等浏览器：</span>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                点击浏览器右上角【三点菜单】➔ 选择【添加到主屏幕】或【安装应用】即可。
              </p>
            </div>
          </div>
        )}

        <div className="mt-5 text-center">
          <button
            onClick={onClose}
            className="text-xs text-slate-400 hover:text-slate-200 underline"
          >
            知道了，继续游戏
          </button>
        </div>
      </div>
    </div>
  );
};
