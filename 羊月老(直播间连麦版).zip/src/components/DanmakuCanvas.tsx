import React, { useEffect, useState } from 'react';
import { BARRAGE_PRESETS } from '../data/demandsData';
import { DanmakuItem } from '../types';

interface DanmakuCanvasProps {
  customMessage?: string | null;
}

export const DanmakuCanvas: React.FC<DanmakuCanvasProps> = ({ customMessage }) => {
  const [danmakuList, setDanmakuList] = useState<DanmakuItem[]>([]);

  // Periodically insert random audience danmaku
  useEffect(() => {
    const interval = setInterval(() => {
      const text = BARRAGE_PRESETS[Math.floor(Math.random() * BARRAGE_PRESETS.length)];
      const users = ["羊村第一深情", "榜一大哥", "隔壁老王", "月老铁粉", "吃瓜群众", "羊羊得意", "吃包子不吐包子皮", "草原追风少年"];
      const colors = ["#FBBF24", "#F43F5E", "#34D399", "#60A5FA", "#C084FC", "#F97316"];

      const newItem: DanmakuItem = {
        id: `dm_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        text,
        user: users[Math.floor(Math.random() * users.length)],
        top: Math.floor(Math.random() * 65) + 5, // 5% to 70% height
        speed: Math.floor(Math.random() * 4) + 6, // 6s - 10s
        color: colors[Math.floor(Math.random() * colors.length)]
      };

      setDanmakuList((prev) => [...prev.slice(-15), newItem]);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  // When customMessage (like Gift broadcast or Match broadcast) arrives
  useEffect(() => {
    if (customMessage) {
      const newItem: DanmakuItem = {
        id: `custom_dm_${Date.now()}`,
        text: customMessage,
        user: "📢 全服广播",
        top: 15,
        speed: 5,
        color: "#FACC15",
        isGiftNotice: true
      };
      setDanmakuList((prev) => [...prev, newItem]);
    }
  }, [customMessage]);

  return (
    <div className="fixed top-16 left-0 right-0 h-40 pointer-events-none z-20 overflow-hidden">
      {danmakuList.map((item) => (
        <div
          key={item.id}
          className="absolute whitespace-nowrap flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold shadow-lg border backdrop-blur-sm animate-danmaku"
          style={{
            top: `${item.top}%`,
            right: '-100%',
            animationDuration: `${item.speed}s`,
            color: item.color || '#FFF',
            backgroundColor: item.isGiftNotice ? 'rgba(220, 38, 38, 0.85)' : 'rgba(15, 23, 42, 0.75)',
            borderColor: item.isGiftNotice ? '#FBBF24' : 'rgba(255, 255, 255, 0.2)'
          }}
        >
          <span className="text-[10px] text-amber-300 font-normal">[{item.user}]</span>
          <span>{item.text}</span>
        </div>
      ))}

      {/* Animation Style */}
      <style>{`
        @keyframes danmaku {
          0% { transform: translateX(0); }
          100% { transform: translateX(-150vw); }
        }
        .animate-danmaku {
          animation-name: danmaku;
          animation-timing-function: linear;
          animation-fill-mode: forwards;
        }
      `}</style>
    </div>
  );
};
