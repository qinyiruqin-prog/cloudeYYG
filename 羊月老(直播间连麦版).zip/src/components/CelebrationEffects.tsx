import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Sparkles, Trophy, Gift, Award } from 'lucide-react';

interface CelebrationEffectsProps {
  milestone: number | null; // 5 or 10 or 20
  onClose: () => void;
}

export const CelebrationEffects: React.FC<CelebrationEffectsProps> = ({ milestone, onClose }) => {
  useEffect(() => {
    if (!milestone) return;

    if (milestone === 5) {
      // 5 Points: Flower Petals (撒花/花瓣)
      const duration = 2500;
      const end = Date.now() + duration;

      const frame = () => {
        confetti({
          particleCount: 4,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: ['#F43F5E', '#FB7185', '#FDA4AF', '#FCD34D']
        });
        confetti({
          particleCount: 4,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: ['#F43F5E', '#FB7185', '#FDA4AF', '#FCD34D']
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      };
      frame();
    } else if (milestone >= 10) {
      // 10 Points: Red Envelopes / Gold Coins Falling (红包/金币暴富)
      const duration = 3000;
      const end = Date.now() + duration;

      const frame = () => {
        confetti({
          particleCount: 6,
          angle: 90,
          spread: 120,
          origin: { y: 0.1 },
          colors: ['#EF4444', '#F59E0B', '#DC2626', '#FBBF24']
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      };
      frame();
    }

    const timer = setTimeout(() => {
      onClose();
    }, 3500);

    return () => clearTimeout(timer);
  }, [milestone, onClose]);

  if (!milestone) return null;

  return (
    <div className="fixed inset-0 z-50 pointer-events-auto flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-gradient-to-b from-red-900 via-amber-950 to-slate-950 rounded-3xl p-6 sm:p-8 max-w-sm w-full text-center border-4 border-amber-400 shadow-2xl shadow-red-600/50 animate-bounce">
        <div className="w-16 h-16 mx-auto mb-3 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center text-3xl shadow-lg border-2 border-white">
          {milestone === 5 ? '🌸' : '🧧'}
        </div>

        <h2 className="text-2xl font-black text-amber-300 tracking-tight">
          {milestone === 5 ? '功德满载 · 仙花飘落！' : '功德无量 · 红包雨来！'}
        </h2>

        <p className="text-sm text-slate-200 mt-2 font-medium">
          {milestone === 5 
            ? '恭喜累计达到 5 分功德！全屏开启撒花祝福！' 
            : `恭喜累计达到 ${milestone} 分功德！斩获【金牌羊月老】红娘成就！`}
        </p>

        <div className="mt-5">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-sm shadow-md transition active:scale-95"
          >
            领功德继续牵线
          </button>
        </div>
      </div>
    </div>
  );
};
