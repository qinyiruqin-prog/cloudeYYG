import React, { useState, useEffect, useRef } from 'react';
import { Send, ThumbsUp, ThumbsDown, Flame, MessageSquare, Pin, Sparkles, User, Award } from 'lucide-react';
import { LiveChatMessage, AudiencePoll, Guest } from '../types';

interface LiveChatRoomProps {
  guest1: Guest | null;
  guest2: Guest | null;
  poll: AudiencePoll;
  onUserVote: (type: 'match' | 'noMatch') => void;
}

const INITIAL_COMMENTS: LiveChatMessage[] = [
  { id: 'c1', user: '羊村第一深情', badge: '榜一', text: '月老好！今天这俩嘉宾的画风有点别致啊！', time: '12:01', color: '#FBBF24' },
  { id: 'c2', user: '隔壁老王', badge: '铁粉', text: '1号麦的离谱要求笑死我了哈哈哈！', time: '12:01', color: '#34D399' },
  { id: 'c3', user: '吃瓜群众小刘', badge: '粉丝', text: '2号麦小哥看起来很靠谱，快牵红线！', time: '12:02', color: '#60A5FA' },
  { id: 'c4', user: '羊场CEO', badge: '房管', text: '大家理性看相亲，把公屏打在【配对】上！', time: '12:02', color: '#F43F5E', isPinned: true },
];

export const LiveChatRoom: React.FC<LiveChatRoomProps> = ({
  guest1,
  guest2,
  poll,
  onUserVote,
}) => {
  const [messages, setMessages] = useState<LiveChatMessage[]>(INITIAL_COMMENTS);
  const [inputText, setInputText] = useState('');
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat to bottom
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Periodic simulated viewer comments related to current guests
  useEffect(() => {
    if (!guest1 || !guest2) return;

    const interval = setInterval(() => {
      const templates = [
        `【${guest1.name}】的要求我直接好家伙！`,
        `这俩人【${guest1.demandKeywords[0] || '要求'}】完全对得上啊！`,
        `羊月老快拍案！这波绝对是天作之合！`,
        `哈哈哈大吃一惊！这就是传说中的羊村缘分吗`,
        `2号麦【${guest2.name}】能顶得住这个要求吗？`,
        `扣1看羊月老直接牵线！`,
        `榜一大哥已就位，牵成了直接送火箭！`
      ];

      const users = ["草原小甜甜", "吃包子不吐皮", "电竞老司机", "二次元追风狗", "月老忠实铁粉", "红娘迷弟"];
      const badges = ["粉丝", "铁粉", "路人", "热心群众", "榜二"];

      const randomText = templates[Math.floor(Math.random() * templates.length)];
      const randomUser = users[Math.floor(Math.random() * users.length)];
      const randomBadge = badges[Math.floor(Math.random() * badges.length)];

      const newMsg: LiveChatMessage = {
        id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        user: randomUser,
        badge: randomBadge,
        text: randomText,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev.slice(-30), newMsg]);
    }, 3500);

    return () => clearInterval(interval);
  }, [guest1, guest2]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const userMsg: LiveChatMessage = {
      id: `user_msg_${Date.now()}`,
      user: '主播羊月老 (你)',
      badge: '主播',
      text: inputText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      color: '#F59E0B',
      isSystem: true
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
  };

  const matchPercent = poll.totalVotes > 0 
    ? Math.round((poll.matchVotes / poll.totalVotes) * 100) 
    : 75;

  return (
    <div className="w-full bg-slate-900/90 rounded-2xl border-2 border-amber-500/40 p-3 shadow-xl backdrop-blur-md flex flex-col h-[320px] sm:h-[360px] justify-between">
      {/* Top Bar: Title & Audience Match Poll */}
      <div className="pb-2 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-xs font-bold text-amber-300">
          <MessageSquare className="w-4 h-4 text-amber-400" />
          <span>直播间实时弹幕讨论</span>
        </div>

        {/* Real-time Audience Poll Widget */}
        <div className="flex items-center gap-2 bg-slate-950/80 px-2.5 py-1 rounded-xl border border-amber-500/30 text-[11px]">
          <span className="text-slate-400 font-medium">观众看好度:</span>
          <span className="font-mono font-bold text-amber-400">{matchPercent}% 看好</span>
          <div className="flex items-center gap-1">
            <button
              onClick={() => onUserVote('match')}
              className="p-1 rounded bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-500/40 text-[10px] flex items-center gap-0.5 active:scale-95"
              title="投看好票"
            >
              <ThumbsUp className="w-3 h-3 text-emerald-400" />
              <span>{poll.matchVotes}</span>
            </button>
            <button
              onClick={() => onUserVote('noMatch')}
              className="p-1 rounded bg-red-950 hover:bg-red-900 text-red-300 border border-red-500/40 text-[10px] flex items-center gap-0.5 active:scale-95"
              title="投不看好票"
            >
              <ThumbsDown className="w-3 h-3 text-red-400" />
              <span>{poll.noMatchVotes}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Messages Stream Container */}
      <div className="flex-1 overflow-y-auto space-y-2 py-2 pr-1 my-1 text-xs font-medium custom-scrollbar">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`p-2 rounded-xl flex items-start gap-1.5 leading-relaxed ${
              m.isPinned
                ? 'bg-red-950/80 border border-red-500/50 text-red-200'
                : m.isSystem
                ? 'bg-amber-950/70 border border-amber-500/50 text-amber-200'
                : 'bg-slate-950/60 border border-slate-800 text-slate-200'
            }`}
          >
            {m.isPinned && <Pin className="w-3.5 h-3.5 text-red-400 flex-shrink-0 mt-0.5" />}
            
            <div className="flex-1">
              <div className="flex items-center gap-1.5 mb-0.5">
                {m.badge && (
                  <span className={`text-[9px] px-1.5 py-0.2 rounded font-black ${
                    m.badge === '主播' 
                      ? 'bg-amber-400 text-slate-950' 
                      : m.badge === '榜一' 
                      ? 'bg-red-600 text-white' 
                      : 'bg-slate-800 text-slate-300'
                  }`}>
                    {m.badge}
                  </span>
                )}
                <span className="font-bold text-amber-300/90 text-[11px]" style={{ color: m.color }}>
                  {m.user}:
                </span>
                <span className="text-[9px] text-slate-500 ml-auto font-mono">{m.time}</span>
              </div>
              <p className="text-slate-100 text-xs break-words">{m.text}</p>
            </div>
          </div>
        ))}
        <div ref={chatBottomRef} />
      </div>

      {/* Streamer Comment Input Bar */}
      <form onSubmit={handleSend} className="pt-2 border-t border-slate-800 flex items-center gap-2">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="作为主播发言带气氛 (例: 这波能成公屏扣1)..."
          className="flex-1 bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl px-3 py-1.5 text-xs text-slate-100 outline-none placeholder:text-slate-500"
        />
        <button
          type="submit"
          className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1 transition active:scale-95"
        >
          <Send className="w-3.5 h-3.5" />
          <span>公屏发言</span>
        </button>
      </form>
    </div>
  );
};
