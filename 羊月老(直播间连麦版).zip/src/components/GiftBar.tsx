import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Gift, Rocket, Flame, Crown, Sparkles, Heart } from 'lucide-react';
import { GiftItem } from '../types';
import { soundManager } from '../utils/audio';

interface GiftBarProps {
  onSendGift: (gift: GiftItem) => void;
}

const GIFTS: GiftItem[] = [
  { id: 'g1', name: '玫瑰鲜花', icon: '🌹', price: 66, animationType: 'rose' },
  { id: 'g2', name: '草原小羊', icon: '🐑', price: 188, animationType: 'alpaca' },
  { id: 'g3', name: '月老皇冠', icon: '👑', price: 520, animationType: 'crown' },
  { id: 'g4', name: '超级火箭', icon: '🚀', price: 1314, animationType: 'rocket' },
  { id: 'g5', name: '爆竹烟花', icon: '🎆', price: 888, animationType: 'fireworks' },
];

export const GiftBar: React.FC<GiftBarProps> = ({ onSendGift }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeGiftAnim, setActiveGiftAnim] = useState<string | null>(null);

  const handleGiftClick = (gift: GiftItem) => {
    soundManager.playGift();
    setActiveGiftAnim(gift.name);

    // Trigger canvas confetti / fireworks effect
    if (gift.animationType === 'fireworks' || gift.animationType === 'rocket') {
      confetti({
        particleCount: 80,
        spread: 100,
        origin: { y: 0.8 },
        colors: ['#EF4444', '#F59E0B', '#10B981', '#3B82F6', '#EC4899']
      });
    } else {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.9 },
        colors: ['#F43F5E', '#FBBF24', '#A855F7']
      });
    }

    onSendGift(gift);

    setTimeout(() => {
      setActiveGiftAnim(null);
    }, 2000);
  };

  return (
    <div className="relative">
      {/* Active flying gift banner preview */}
      {activeGiftAnim && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 bg-gradient-to-r from-red-600 via-amber-500 to-red-600 text-slate-950 px-6 py-2.5 rounded-full font-black text-sm sm:text-base shadow-2xl border-2 border-amber-300 flex items-center gap-2 animate-bounce">
          <Sparkles className="w-5 h-5 text-slate-950" />
          <span>全服感谢：榜一大哥送出了【{activeGiftAnim}】！</span>
        </div>
      )}

      {/* Gift Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-red-600 hover:from-amber-400 hover:to-red-500 text-slate-950 font-black text-xs sm:text-sm shadow-md border border-amber-300 transition active:scale-95"
      >
        <Gift className="w-4 h-4 fill-slate-950" />
        <span>送礼物彩蛋</span>
      </button>

      {/* Gift Picker Drawer / Popover */}
      {isOpen && (
        <div className="absolute bottom-12 right-0 z-40 bg-slate-900/95 border-2 border-amber-500/50 rounded-2xl p-3 shadow-2xl backdrop-blur-md w-72 sm:w-80">
          <div className="flex items-center justify-between mb-2 pb-1.5 border-b border-slate-800">
            <span className="text-xs font-bold text-amber-300 flex items-center gap-1">
              <Gift className="w-3.5 h-3.5 text-amber-400" /> 直播间直播氛围礼物
            </span>
            <button
              onClick={() => setIsOpen(false)}
              className="text-xs text-slate-400 hover:text-white"
            >
              ✕
            </button>
          </div>

          <div className="grid grid-cols-5 gap-1.5">
            {GIFTS.map((g) => (
              <button
                key={g.id}
                onClick={() => handleGiftClick(g)}
                className="flex flex-col items-center justify-center p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/80 hover:border-amber-400/80 transition active:scale-90 group"
              >
                <span className="text-2xl group-hover:scale-125 transition-transform duration-200">{g.icon}</span>
                <span className="text-[10px] text-slate-200 font-bold mt-1 line-clamp-1">{g.name}</span>
                <span className="text-[9px] text-amber-400 font-mono mt-0.5">{g.price} 羊币</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
