import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Key, Cpu, Zap, CheckCircle2, XCircle, RefreshCw, Copy, ExternalLink, Sparkles, X, ShieldAlert } from 'lucide-react';

interface ApiConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedModel: string;
  setSelectedModel: (model: string) => void;
}

interface ModelItem {
  id: string;
  name: string;
  status: string;
  speed: string;
  desc: string;
  recommended?: boolean;
}

export const ApiConfigModal: React.FC<ApiConfigModalProps> = ({
  isOpen,
  onClose,
  selectedModel,
  setSelectedModel,
}) => {
  const [apiKey, setApiKey] = useState<string>(() => localStorage.getItem('user_gemini_api_key') || '');
  const [baseUrl, setBaseUrl] = useState<string>(() => localStorage.getItem('user_gemini_api_base_url') || '');
  const [isTesting, setIsTesting] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);
  const [testResult, setTestResult] = useState<{
    success: boolean;
    latencyMs?: number;
    message?: string;
    model?: string;
    sampleText?: string;
  } | null>(null);

  const [models, setModels] = useState<ModelItem[]>([
    { id: 'gemini-2.5-flash', name: 'Gemini 2.5 Flash', status: 'Active', speed: '⚡ 极速', desc: '综合性价比最高，响应极快，推荐主播实时分析使用', recommended: true },
    { id: 'gemini-2.5-pro', name: 'Gemini 2.5 Pro', status: 'Active', speed: '🧠 高智商', desc: '深度推理模型，精准审核深度离谱择偶要求与家境资产匹配度' },
    { id: 'gemini-2.0-flash', name: 'Gemini 2.0 Flash', status: 'Active', speed: '🚀 超低时延', desc: '毫秒级响应，适合实时直播弹幕交互与互动口白' },
    { id: 'gemini-1.5-flash', name: 'Gemini 1.5 Flash', status: 'Active', speed: '平衡', desc: '经典稳定版本模型' },
  ]);

  const [copiedLink, setCopiedLink] = useState(false);
  const currentAppUrl = typeof window !== 'undefined' ? window.location.href : '';

  // Extract / Fetch available models from backend
  const handleExtractModels = async () => {
    setIsExtracting(true);
    try {
      const res = await fetch('/api/models', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiKey, baseUrl }),
      });
      const data = await res.json();
      if (data.success && data.models) {
        setModels(data.models);
      }
    } catch (err) {
      console.error('Failed to extract models:', err);
    } finally {
      setIsExtracting(false);
    }
  };

  // Test API connection
  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    const start = Date.now();

    try {
      const res = await fetch('/api/test-connection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiKey, baseUrl, model: selectedModel }),
      });
      const data = await res.json();
      const latency = Date.now() - start;

      if (data.success) {
        setTestResult({
          success: true,
          latencyMs: data.latencyMs || latency,
          message: data.message || 'API 中转站 / 节点连接测试成功！通信正常。',
          model: data.model || selectedModel,
          sampleText: data.sampleResponse || '【羊月老AI控场中枢】中转站代理连接就绪！',
        });
      } else {
        setTestResult({
          success: false,
          message: data.error || '连接测试失败，请检查 API Key 权限或中转站 Base URL 格式。',
        });
      }
    } catch (err) {
      setTestResult({
        success: false,
        message: '无法访问服务端接口或中转节点，请确认网络畅通。' + (err as Error).message,
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handleSaveApiKey = (val: string) => {
    setApiKey(val);
    localStorage.setItem('user_gemini_api_key', val);
  };

  const handleSaveBaseUrl = (val: string) => {
    setBaseUrl(val);
    localStorage.setItem('user_gemini_api_base_url', val);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(currentAppUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className="w-full max-w-xl bg-slate-900 border-2 border-amber-500/50 rounded-2xl shadow-2xl overflow-hidden flex flex-col my-auto"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-red-950 via-slate-900 to-amber-950 p-4 border-b border-amber-500/30 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40">
                <Cpu className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h3 className="text-base font-black text-amber-300">
                  AI 模型提取 & API 连通性测试
                </h3>
                <p className="text-[11px] text-slate-400">
                  配置 Gemini 接口凭据、提取可用大模型并测试连通状态
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-4 space-y-4 max-h-[80vh] overflow-y-auto custom-scrollbar">
            {/* App URL Share Section */}
            <div className="bg-slate-950/80 rounded-xl p-3 border border-amber-500/30">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-amber-300 flex items-center gap-1">
                  <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
                  当前应用访问网址 (Share Link):
                </span>
                <span className="text-[10px] text-emerald-400">🟢 独立部署运行中</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={currentAppUrl}
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono select-all outline-none"
                />
                <button
                  onClick={handleCopyLink}
                  className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1 transition active:scale-95"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedLink ? '已复制！' : '复制网址'}</span>
                </button>
                <a
                  href={currentAppUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 transition"
                  title="在新窗口打开"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* API Key & Relay Station Input Section */}
            <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Key className="w-4 h-4 text-amber-400" />
                  <span>Gemini API Key 秘钥配置</span>
                </label>
                <span className="text-[10px] text-slate-400">
                  (留空优先使用默认服务器环境变量)
                </span>
              </div>

              <input
                type="password"
                value={apiKey}
                onChange={(e) => handleSaveApiKey(e.target.value)}
                placeholder="AI Studio API Key (AIzaSy...)"
                className="w-full bg-slate-900 border border-slate-700 focus:border-amber-400 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none font-mono placeholder:text-slate-600"
              />

              <div className="pt-2 border-t border-slate-800/80 space-y-1">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>API 中转站 / 代理节点地址 (Custom Base URL)</span>
                  </label>
                  <span className="text-[10px] text-emerald-400">支持各类中转站</span>
                </div>
                <input
                  type="text"
                  value={baseUrl}
                  onChange={(e) => handleSaveBaseUrl(e.target.value)}
                  placeholder="https://generativelanguage.googleapis.com 或自定义中转站地址"
                  className="w-full bg-slate-900 border border-slate-700 focus:border-amber-400 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none font-mono placeholder:text-slate-600"
                />
                <p className="text-[10px] text-slate-400">
                  💡 如果使用中转站（如代理 API 域名），请输入完整的 HTTP/HTTPS 前缀。留空默认连接官方节点。
                </p>
              </div>
            </div>

            {/* Model Extraction Section */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Cpu className="w-4 h-4 text-emerald-400" />
                  <span>提取可用模型列表 (Model Extraction)</span>
                </span>

                <button
                  onClick={handleExtractModels}
                  disabled={isExtracting}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-[11px] font-bold flex items-center gap-1 transition active:scale-95 disabled:opacity-50"
                >
                  <RefreshCw className={`w-3 h-3 ${isExtracting ? 'animate-spin' : ''}`} />
                  <span>{isExtracting ? '提取中...' : '提取/刷新模型'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {models.map((m) => (
                  <label
                    key={m.id}
                    onClick={() => setSelectedModel(m.id)}
                    className={`cursor-pointer rounded-xl p-2.5 border transition flex flex-col justify-between relative ${
                      selectedModel === m.id
                        ? 'bg-amber-950/60 border-amber-400 text-amber-100 shadow-lg'
                        : 'bg-slate-950/50 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5">
                        <input
                          type="radio"
                          name="model_select"
                          checked={selectedModel === m.id}
                          onChange={() => setSelectedModel(m.id)}
                          className="accent-amber-400"
                        />
                        <span className="text-xs font-black">{m.name}</span>
                      </div>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-emerald-300 font-mono">
                        {m.speed}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 leading-tight">{m.desc}</p>
                    {m.recommended && (
                      <span className="absolute -top-1.5 -right-1.5 bg-amber-400 text-slate-950 text-[9px] font-black px-1.5 py-0.2 rounded-full">
                        推荐
                      </span>
                    )}
                  </label>
                ))}
              </div>
            </div>

            {/* Test Connection Section */}
            <div className="pt-2 border-t border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <span>连通性测试 (Test Connection)</span>
                </span>

                <button
                  onClick={handleTestConnection}
                  disabled={isTesting}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-red-600 hover:from-amber-400 hover:to-red-500 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md shadow-red-950 transition active:scale-95 disabled:opacity-50"
                >
                  <Zap className={`w-3.5 h-3.5 ${isTesting ? 'animate-bounce' : ''}`} />
                  <span>{isTesting ? '正在测试连接...' : '测试 API 连通性'}</span>
                </button>
              </div>

              {/* Test Result Display */}
              {testResult && (
                <motion.div
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`p-3 rounded-xl border text-xs ${
                    testResult.success
                      ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-200'
                      : 'bg-red-950/70 border-red-500/50 text-red-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-1.5 font-bold">
                      {testResult.success ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <XCircle className="w-4 h-4 text-red-400" />
                      )}
                      <span>{testResult.message}</span>
                    </div>
                    {testResult.latencyMs && (
                      <span className="text-[10px] font-mono bg-slate-900/80 px-2 py-0.5 rounded border border-emerald-500/30 text-emerald-300">
                        延迟: {testResult.latencyMs} ms
                      </span>
                    )}
                  </div>

                  {testResult.sampleText && (
                    <div className="mt-2 pt-2 border-t border-emerald-500/30 text-[11px] font-mono text-emerald-100 bg-slate-950/60 p-2 rounded-lg">
                      <span className="text-[10px] text-emerald-400 font-bold block mb-0.5">测试返回响应内容：</span>
                      "{testResult.sampleText}"
                    </div>
                  )}
                </motion.div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="bg-slate-950 p-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>选定模型: <strong className="text-amber-300 font-mono">{selectedModel}</strong></span>
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold transition"
            >
              完成并返回直播间
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
