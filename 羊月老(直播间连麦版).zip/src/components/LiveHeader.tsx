import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, History, Download, Sparkles, Users, Radio, Flame, Cpu } from 'lucide-react';
import { soundManager } from '../utils/audio';

interface LiveHeaderProps {
  meritPoints: number;
  onOpenHistory: () => void;
  onOpenInstall: () => void;
  onOpenApiConfig: () => void;
  soundEnabled: boolean;
  setSoundEnabled: (val: boolean) => void;
}

export const LiveHeader: React.FC<LiveHeaderProps> = ({
  meritPoints,
  onOpenHistory,
  onOpenInstall,
  onOpenApiConfig,
  soundEnabled,
  setSoundEnabled,
}) => {
  const [viewerCount, setViewerCount] = useState(5820);

  // Dynamic online viewers fluctuation
  useEffect(() => {
    const interval = setInterval(() => {
      const delta = Math.floor(Math.random() * 25) - 10;
      setViewerCount((prev) => Math.max(100, Math.min(9999, prev + delta)));
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundManager.enabled = next;
    if (next) soundManager.playMicConnect();
  };

  // Next milestone calculation
  const nextMilestone = meritPoints < 5 ? 5 : meritPoints < 10 ? 10 : meritPoints < 20 ? 20 : 50;
  const progressPercent = Math.min(100, Math.max(0, (meritPoints / nextMilestone) * 100));

  return (
    <header className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-amber-500/30 px-3 py-2 sm:px-6 sm:py-3 shadow-lg">
      <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-2">
        {/* Left: App Logo & Live Status */}
        <div className="flex items-center gap-2.5">
          <div className="relative group cursor-pointer">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-gradient-to-tr from-red-600 via-amber-500 to-emerald-600 p-0.5 shadow-md shadow-red-500/20">
              <div className="w-full h-full bg-slate-950 rounded-full flex items-center justify-center relative overflow-hidden">
                <span className="text-xl sm:text-2xl">🐑</span>
                <span className="absolute -bottom-0.5 right-0 text-xs">🧵</span>
              </div>
            </div>
            <div className="absolute -bottom-1 -right-1 bg-red-600 text-white text-[10px] px-1 py-0.2 rounded-full font-bold animate-pulse">
              LIVE
            </div>
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-base sm:text-lg font-black text-transparent bg-clip-text bg-gradient-to-r from-red-400 via-amber-300 to-emerald-400 tracking-tight">
                羊月老 <span className="text-xs font-semibold px-1.5 py-0.5 rounded bg-red-950/80 text-red-300 border border-red-500/40">连麦相亲</span>
              </h1>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-300 mt-0.5">
              <span className="inline-flex items-center gap-1 text-emerald-400 bg-emerald-950/50 px-1.5 py-0.5 rounded-full border border-emerald-500/30 text-[11px]">
                <Radio className="w-3 h-3 animate-ping text-emerald-400" /> 直播中
              </span>
              <span className="inline-flex items-center gap-1 text-slate-300 text-[11px]">
                <Users className="w-3 h-3 text-amber-400" />
                <span className="font-mono font-bold text-amber-300">{viewerCount.toLocaleString()}</span> 人在线
              </span>
            </div>
          </div>
        </div>

        {/* Center: Merit Value Counter */}
        <div className="flex items-center gap-3 bg-slate-800/90 border border-amber-500/40 rounded-xl px-3 py-1.5 shadow-inner">
          <div className="flex items-center gap-1.5">
            <span className="text-xl animate-bounce">📿</span>
            <div>
              <div className="text-[10px] text-amber-300/80 font-medium">当前月老功德</div>
              <div className="flex items-baseline gap-1">
                <span className="text-lg sm:text-xl font-black text-amber-300 font-mono drop-shadow">
                  {meritPoints}
                </span>
                <span className="text-xs text-slate-400">分</span>
              </div>
            </div>
          </div>

          {/* Progress to next milestone */}
          <div className="hidden sm:block w-20 space-y-1">
            <div className="flex justify-between text-[10px] text-amber-200/70">
              <span>下一阶段</span>
              <span>{nextMilestone}分</span>
            </div>
            <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-700">
              <div
                className="bg-gradient-to-r from-amber-500 via-emerald-400 to-red-500 h-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Right: Quick Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* AI API & Model Config Button */}
          <button
            onClick={onOpenApiConfig}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-amber-950/80 hover:bg-amber-900 text-amber-300 border border-amber-500/50 shadow transition active:scale-95 text-xs font-bold"
            title="提取AI模型并测试API连通性"
          >
            <Cpu className="w-4 h-4 text-amber-400 animate-pulse" />
            <span className="hidden xs:inline">API/网址</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition active:scale-95"
            title={soundEnabled ? "关闭音效" : "开启音效"}
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-400" />
            )}
          </button>

          {/* History Drawer Toggle */}
          <button
            onClick={onOpenHistory}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition active:scale-95 text-xs font-medium"
          >
            <History className="w-4 h-4 text-amber-400" />
            <span className="hidden xs:inline">连麦记录</span>
          </button>

          {/* Install App Button */}
          <button
            onClick={onOpenInstall}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-medium shadow-md shadow-emerald-900/30 transition active:scale-95 text-xs"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">安装到主页</span>
          </button>
        </div>
      </div>
    </header>
  );
};
