import React from 'react';
import { History, Heart, HeartOff, Sparkles, X } from 'lucide-react';
import { MatchResult } from '../types';

interface HistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  history: MatchResult[];
}

export const HistoryDrawer: React.FC<HistoryDrawerProps> = ({ isOpen, onClose, history }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/70 backdrop-blur-sm">
      <div className="w-full max-w-md bg-slate-900 border-l border-amber-500/30 h-full p-4 sm:p-6 overflow-y-auto flex flex-col justify-between shadow-2xl">
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <History className="w-5 h-5 text-amber-400" />
              <h2 className="text-lg font-black text-slate-100">最近连麦记录 ({history.length})</h2>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Records List */}
          <div className="mt-4 space-y-3">
            {history.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-sm">
                <p>暂无连麦记录，快点击“牵红线”吧！</p>
              </div>
            ) : (
              history.map((item) => (
                <div
                  key={item.id}
                  className={`p-3.5 rounded-2xl border text-xs relative overflow-hidden transition ${
                    item.isMatch
                      ? 'bg-slate-850 border-amber-500/40 hover:border-amber-400'
                      : 'bg-slate-900/90 border-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      item.isMatch ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {item.isMatch ? '🔥 牵线成功' : '💔 牵线失败'} ({item.score}% 契合)
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  {/* Pair Info */}
                  <div className="flex items-center gap-2 my-1">
                    <div className="flex items-center gap-1">
                      <img src={item.guest1.avatar} alt="" className="w-6 h-6 rounded-full object-cover" />
                      <span className="font-bold text-slate-200">{item.guest1.name}</span>
                    </div>

                    <span className="text-slate-500">vs</span>

                    <div className="flex items-center gap-1">
                      <img src={item.guest2.avatar} alt="" className="w-6 h-6 rounded-full object-cover" />
                      <span className="font-bold text-slate-200">{item.guest2.name}</span>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-300 mt-2 bg-slate-950/60 p-2 rounded-lg border border-slate-800 line-clamp-2">
                    “{item.commentary}”
                  </p>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="pt-4 border-t border-slate-800">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs"
          >
            关闭连麦记录
          </button>
        </div>
      </div>
    </div>
  );
};
