import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, HeartOff, Sparkles, AlertTriangle, ArrowRight, Pause, Play, Trophy } from 'lucide-react';
import { MatchResult } from '../types';

interface MatchResultOverlayProps {
  result: MatchResult | null;
  onNext: () => void;
  isAutoAdvancing: boolean;
  setIsAutoAdvancing: (val: boolean) => void;
}

export const MatchResultOverlay: React.FC<MatchResultOverlayProps> = ({
  result,
  onNext,
  isAutoAdvancing,
  setIsAutoAdvancing,
}) => {
  const [countdown, setCountdown] = useState(1.5);

  useEffect(() => {
    if (!result) return;
    setCountdown(1.5);

    if (!isAutoAdvancing) return;

    const startTime = Date.now();
    const duration = 1500; // 1.5 seconds exact requirement

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const remaining = Math.max(0, (duration - elapsed) / 1000);
      setCountdown(remaining);

      if (remaining <= 0) {
        clearInterval(interval);
        onNext();
      }
    }, 50);

    return () => clearInterval(interval);
  }, [result, isAutoAdvancing, onNext]);

  if (!result) return null;

  const isSuccess = result.isMatch;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
        <motion.div
          initial={{ scale: 0.8, opacity: 0, y: 20 }}
          animate={{ 
            scale: 1, 
            opacity: 1, 
            y: 0,
            x: isSuccess ? 0 : [0, -10, 10, -10, 10, 0] // Jitter shake animation for failure
          }}
          exit={{ scale: 0.8, opacity: 0 }}
          transition={{ duration: 0.3 }}
          className={`w-full max-w-md rounded-3xl p-5 sm:p-6 shadow-2xl border-4 relative overflow-hidden ${
            isSuccess
              ? 'bg-gradient-to-b from-red-950 via-slate-900 to-amber-950 border-amber-400 shadow-red-600/50'
              : 'bg-gradient-to-b from-slate-900 via-slate-850 to-slate-900 border-slate-600 shadow-black/80'
          }`}
        >
          {/* Background Golden Rays / Particle Glow */}
          {isSuccess && (
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-amber-500/20 via-transparent to-transparent pointer-events-none animate-pulse" />
          )}

          {/* Top Badge */}
          <div className="flex justify-center mb-3">
            <span className={`inline-flex items-center gap-1.5 px-4 py-1 rounded-full text-xs font-black tracking-wider uppercase border shadow-md ${
              isSuccess
                ? 'bg-amber-400 text-slate-950 border-amber-300 animate-bounce'
                : 'bg-slate-800 text-slate-300 border-slate-600'
            }`}>
              {isSuccess ? <Sparkles className="w-4 h-4 fill-current" /> : <AlertTriangle className="w-4 h-4 text-amber-400" />}
              <span>{isSuccess ? '🔥 牵线成功 · 功德 +1' : '💔 牵线失败 · 功德 -1'}</span>
            </span>
          </div>

          {/* Icon & Pairing Visual */}
          <div className="flex items-center justify-center gap-3 my-4">
            <div className="relative">
              <img
                src={result.guest1.avatar}
                alt={result.guest1.name}
                className="w-14 h-14 sm:w-16 sm:h-16 rounded-full border-2 border-amber-400 object-cover shadow-md"
              />
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-slate-950 text-slate-200 text-[10px] font-bold px-1.5 py-0.2 rounded-full border border-slate-700">
                {result.guest1.name}
              </span>
            </div>

            <div className="flex flex-col items-center">
              {isSuccess ? (
                <div className="w-12 h-12 rounded-full bg-red-600/30 border-2 border-red-500 flex items-center justify-center animate-pulse">
                  <Heart className="w-6 h-6 text-red-400 fill-red-500 animate-bounce" />
                </div>
              ) : (
                <div className="w-12 h-12 rounded-full bg-slate-800 border-2 border-slate-600 flex items-center justify-center">
                  <HeartOff className="w-6 h-6 text-slate-400" />
                </div>
              )}
              <span className={`text-xs font-black font-mono mt-1 ${isSuccess ? 'text-amber-300' : 'text-slate-400'}`}>
                {result.score}% 契合度
              </span>
            </div>

            <div className="relative">
              <img
                src={result.guest2.avatar}
                alt={result.guest2.name}
                className="w-14 h-14 sm:w-16 sm:h-16 rounded-full border-2 border-amber-400 object-cover shadow-md"
              />
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-slate-950 text-slate-200 text-[10px] font-bold px-1.5 py-0.2 rounded-full border border-slate-700">
                {result.guest2.name}
              </span>
            </div>
          </div>

          {/* Red Maiden Commentary Box */}
          <div className="bg-slate-950/80 rounded-2xl p-4 border border-amber-500/30 mb-4 shadow-inner">
            <div className="text-[11px] font-bold text-amber-400 flex items-center gap-1 mb-1">
              <span>🗣️ 羊月老红娘点评：</span>
            </div>
            <p className="text-sm font-bold text-slate-100 leading-relaxed">
              “{result.commentary}”
            </p>
          </div>

          {/* Auto Advance Countdown Bar & Controls */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-300 font-medium px-1">
              <span>{isAutoAdvancing ? `${countdown.toFixed(1)}s 后自动下一对...` : '自动刷新已暂停'}</span>
              <button
                onClick={() => setIsAutoAdvancing(!isAutoAdvancing)}
                className="text-amber-400 hover:underline flex items-center gap-1 text-[11px]"
              >
                {isAutoAdvancing ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                {isAutoAdvancing ? '暂停倒计时' : '继续倒计时'}
              </button>
            </div>

            {/* Countdown Progress Bar */}
            <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden border border-slate-700">
              <div
                className={`h-full transition-all duration-75 ${
                  isSuccess ? 'bg-gradient-to-r from-red-500 to-amber-400' : 'bg-slate-500'
                }`}
                style={{ width: `${(countdown / 1.5) * 100}%` }}
              />
            </div>

            {/* Jump Button */}
            <button
              onClick={onNext}
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm flex items-center justify-center gap-1.5 shadow-md transition active:scale-95"
            >
              <span>立即切换下一对嘉宾</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
