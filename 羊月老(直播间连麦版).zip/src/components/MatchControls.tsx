import React from 'react';
import { Heart, RefreshCw, Zap, Play, Pause, Sparkles, ArrowRight } from 'lucide-react';

interface MatchControlsProps {
  onMatch: () => void;
  onRefresh: () => void;
  isEvaluating: boolean;
  isLoadingNew: boolean;
  autoMode: boolean;
  setAutoMode: (val: boolean) => void;
}

export const MatchControls: React.FC<MatchControlsProps> = ({
  onMatch,
  onRefresh,
  isEvaluating,
  isLoadingNew,
  autoMode,
  setAutoMode,
}) => {
  return (
    <div className="w-full bg-slate-900/90 rounded-2xl border-2 border-amber-500/40 p-3 sm:p-4 shadow-2xl backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-3">
      {/* Left: Auto Match Toggle */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setAutoMode(!autoMode)}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition border ${
            autoMode
              ? 'bg-emerald-600 text-white border-emerald-400 shadow-lg shadow-emerald-600/30 animate-pulse'
              : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
          }`}
        >
          {autoMode ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
          <span>{autoMode ? '自动快连中 (1.5s)' : '开启自动连麦'}</span>
        </button>
        <span className="text-[11px] text-slate-400 hidden md:inline">
          {autoMode ? '判定结果后1.5s自动换下一对' : '审阅两位嘉宾后点击牵线'}
        </span>
      </div>

      {/* Center: Primary Big Match Button & Pass Button */}
      <div className="flex items-center gap-2.5 w-full sm:w-auto">
        {/* Pass Button */}
        <button
          onClick={onRefresh}
          disabled={isEvaluating || isLoadingNew}
          className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 text-xs sm:text-sm font-bold border border-slate-600 transition disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 text-slate-400 ${isLoadingNew ? 'animate-spin' : ''}`} />
          <span>换一批嘉宾</span>
        </button>

        {/* Primary Streamer "牵红线·拍案定音" Button */}
        <button
          onClick={onMatch}
          disabled={isEvaluating || isLoadingNew}
          className="flex-[2] sm:flex-none flex items-center justify-center gap-2 px-6 sm:px-8 py-3 rounded-xl bg-gradient-to-r from-red-600 via-amber-400 to-red-600 hover:from-red-500 hover:via-amber-300 hover:to-red-500 text-slate-950 font-black text-base sm:text-lg shadow-xl shadow-red-600/50 border-2 border-amber-300 transition transform active:scale-95 disabled:opacity-50 group relative overflow-hidden"
        >
          <span className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 pointer-events-none" />
          <Heart className="w-5 h-5 fill-slate-950 text-slate-950 animate-bounce" />
          <span>主播拍案 · 牵红线</span>
          <Sparkles className="w-4 h-4 text-slate-950" />
        </button>
      </div>

      {/* Right: Quick hint badge */}
      <div className="hidden lg:flex items-center gap-1 text-xs text-amber-300/80 bg-amber-950/40 px-3 py-1.5 rounded-lg border border-amber-500/30">
        <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
        <span>成功+1功德，失败-1功德</span>
      </div>
    </div>
  );
};
