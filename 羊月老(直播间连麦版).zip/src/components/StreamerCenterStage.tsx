import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Mic, Radio, Volume2, Sparkles, Award, Flame, MessageCircle, HelpCircle } from 'lucide-react';
import { StreamerStats, Guest } from '../types';
import { soundManager } from '../utils/audio';

interface StreamerCenterStageProps {
  stats: StreamerStats;
  guest1: Guest | null;
  guest2: Guest | null;
  onStreamerAsk: (targetMic: 1 | 2) => void;
  onPlaySfx: (type: 'goat' | 'applause' | 'gavel' | 'alarm') => void;
}

export const StreamerCenterStage: React.FC<StreamerCenterStageProps> = ({
  stats,
  guest1,
  guest2,
  onStreamerAsk,
  onPlaySfx,
}) => {
  const [streamTime, setStreamTime] = useState(0);
  const [activeSpeech, setActiveSpeech] = useState<string>('家人们好！我是主播羊月老，欢迎来到直播间！');

  // Live timer
  useEffect(() => {
    const timer = setInterval(() => {
      setStreamTime((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  return (
    <div className="w-full bg-gradient-to-b from-red-950/90 via-slate-900 to-slate-950 rounded-2xl border-2 border-amber-500/50 p-3 sm:p-4 shadow-2xl relative overflow-hidden flex flex-col justify-between">
      {/* Streamer Header Banner */}
      <div className="flex items-center justify-between border-b border-amber-500/30 pb-2 mb-2">
        <div className="flex items-center gap-2">
          <span className="flex h-2.5 w-2.5 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
          </span>
          <span className="text-xs font-black text-amber-300 tracking-wider">
            主 播 控 场 中 枢
          </span>
          <span className="text-[10px] bg-red-900/80 text-red-200 px-2 py-0.5 rounded-full border border-red-500/40 font-mono">
            直播 {formatTime(streamTime)}
          </span>
        </div>

        <div className="flex items-center gap-1.5 text-[11px] text-amber-200 font-bold bg-amber-950/60 px-2.5 py-0.5 rounded-full border border-amber-500/30">
          <Award className="w-3.5 h-3.5 text-amber-400" />
          <span>Lv.{stats.level} {stats.title}</span>
        </div>
      </div>

      {/* Streamer Avatar & Real-time Speech Box */}
      <div className="flex flex-col sm:flex-row items-center gap-3 my-1">
        {/* Streamer Video Frame */}
        <div className="relative group flex-shrink-0">
          <div className="w-20 h-20 sm:w-22 sm:h-22 rounded-full bg-gradient-to-tr from-amber-400 via-red-500 to-emerald-400 p-1 shadow-lg shadow-amber-500/20">
            <div className="w-full h-full bg-slate-950 rounded-full flex items-center justify-center relative overflow-hidden border-2 border-slate-900">
              <span className="text-3xl animate-bounce">🐑</span>
              {/* Mic Icon overlay */}
              <div className="absolute bottom-0 inset-x-0 bg-red-600/90 text-white text-[9px] font-black text-center py-0.5">
                主播 microphone
              </div>
            </div>
          </div>

          <div className="absolute -top-1 -right-1 bg-amber-400 text-slate-950 text-[10px] font-black px-1.5 py-0.5 rounded-full shadow">
            控场中
          </div>
        </div>

        {/* Streamer Speech Bubble & Live Goal */}
        <div className="flex-1 w-full">
          <div className="bg-slate-950/90 rounded-2xl p-3 border border-amber-500/40 shadow-inner relative">
            <div className="absolute -left-2 top-4 w-2 h-2 bg-slate-950 rotate-45 border-l border-b border-amber-500/40 hidden sm:block" />
            <div className="text-[10px] font-bold text-amber-400 flex items-center justify-between mb-1">
              <span className="flex items-center gap-1">
                <Mic className="w-3 h-3 text-red-400 animate-pulse" />
                <span>主播【羊月老】现场口白：</span>
              </span>
              <span className="text-slate-400 font-mono">
                今日考核: {stats.pairedCount}/{stats.todayGoal} 对
              </span>
            </div>
            <p className="text-xs sm:text-sm font-bold text-slate-100 leading-relaxed italic">
              “{activeSpeech}”
            </p>
          </div>
        </div>
      </div>

      {/* Streamer Live Interactive Soundboard (主播音效包) */}
      <div className="mt-2 pt-2 border-t border-slate-800">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[10px] font-bold text-slate-400 flex items-center gap-1">
            <Volume2 className="w-3 h-3 text-emerald-400" />
            <span>主播控场音效包（点击按键带起直播间氛围）：</span>
          </span>
          <span className="text-[10px] text-amber-300">音浪收益: 🪙 {stats.coinsEarned}</span>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
          <button
            onClick={() => {
              onPlaySfx('goat');
              setActiveSpeech('咩~~~ 羊月老在此，这离谱要求我看不懂但大受震撼！');
            }}
            className="flex items-center justify-center gap-1 py-1.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition active:scale-95"
          >
            <span>🐐 咩~羊叫</span>
          </button>

          <button
            onClick={() => {
              onPlaySfx('applause');
              setActiveSpeech('掌声鼓励！家人们把支持打在公屏上！');
            }}
            className="flex items-center justify-center gap-1 py-1.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition active:scale-95"
          >
            <span>👏👏 鼓掌</span>
          </button>

          <button
            onClick={() => {
              onPlaySfx('gavel');
              setActiveSpeech('拍案！本红娘认为这波要求有戏，准备拉红线！');
            }}
            className="flex items-center justify-center gap-1 py-1.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition active:scale-95"
          >
            <span>💥 拍案</span>
          </button>

          <button
            onClick={() => {
              onPlaySfx('alarm');
              setActiveSpeech('预警！这离谱要求过于惊世骇俗，建议严加审问！');
            }}
            className="flex items-center justify-center gap-1 py-1.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition active:scale-95"
          >
            <span>🚨 警报</span>
          </button>

          {/* Ask Guest 1 Button */}
          <button
            onClick={() => {
              onStreamerAsk(1);
              setActiveSpeech(`1号麦【${guest1?.name || '嘉宾'}】，讲讲你的家境【${guest1?.familyAsset || 'A9/A8'}】和父母告知情况！`);
            }}
            className="flex items-center justify-center gap-1 py-1.5 px-2 rounded-xl bg-gradient-to-r from-amber-600 to-red-600 hover:from-amber-500 hover:to-red-500 text-white text-xs font-bold border border-amber-400 transition active:scale-95"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>连麦1号嘉宾</span>
          </button>

          {/* Ask Guest 2 Button */}
          <button
            onClick={() => {
              onStreamerAsk(2);
              setActiveSpeech(`2号麦【${guest2?.name || '嘉宾'}】，你的彩礼期望和表里体能指标如何？`);
            }}
            className="flex items-center justify-center gap-1 py-1.5 px-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold border border-teal-300 transition active:scale-95"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>连麦2号嘉宾</span>
          </button>
        </div>
      </div>
    </div>
  );
};
