export interface Guest {
  id: string;
  name: string;
  gender: 'male' | 'female';
  age: number;
  avatar: string;
  occupation: string;
  personality: string[];
  seriousDemand: string;
  outrageousDemand: string;
  demandKeywords: string[];
  micNumber: 1 | 2;
  isOnline: boolean;
  currentSpeech?: string;
  isMuted?: boolean;
  // New specific attributes from user request:
  familyAsset: string; // e.g. A9, A9+1, A8等身家背景
  healthCondition: string; // 身体状况（内表健康、体能、外貌体态）
  parentInfo: string; // 父母知情状况及父母择偶期望
  bridePriceDemand: string; // 彩礼/聘礼/高价身价期望
  connectionStatus?: 'connecting' | 'connected' | 'speaking'; // 逐个独立连麦状态
}

export interface MatchResult {
  id: string;
  timestamp: Date;
  guest1: Guest;
  guest2: Guest;
  isMatch: boolean;
  score: number; // 0 - 100
  matchedKeywords: string[];
  commentary: string;
  meritDelta: number;
}

export interface DanmakuItem {
  id: string;
  text: string;
  user: string;
  avatar?: string;
  top: number; // percentage from top 5% to 85%
  speed: number; // duration in seconds
  color?: string;
  isGiftNotice?: boolean;
}

export interface LiveChatMessage {
  id: string;
  user: string;
  avatar?: string;
  badge?: string;
  text: string;
  time: string;
  color?: string;
  isGift?: boolean;
  isSystem?: boolean;
  isPinned?: boolean;
}

export interface AudiencePoll {
  matchVotes: number;
  noMatchVotes: number;
  totalVotes: number;
}

export interface StreamerStats {
  level: number;
  title: string;
  pairedCount: number;
  todayGoal: number;
  coinsEarned: number;
  liveTimeSeconds: number;
}

export interface GiftItem {
  id: string;
  name: string;
  icon: string;
  price: number;
  animationType: 'rocket' | 'rose' | 'alpaca' | 'crown' | 'fireworks';
}

export interface MatchDemandPair {
  demandA: string;
  keywordsA: string[];
  demandB: string;
  keywordsB: string[];
  reason: string;
}

