import { MatchDemandPair } from '../types';

export const COMPLEMENTARY_PAIRS: MatchDemandPair[] = [
  {
    demandA: "每天必须给我做四菜一汤，但我只负责洗碗",
    keywordsA: ["做饭", "洗碗", "美食"],
    demandB: "超级沉迷烹饪Chef级别，急需一个甘愿洗碗的人",
    keywordsB: ["做饭", "洗碗", "烹饪"],
    reason: "一个热爱下厨，一个甘愿洗碗，堪称厨房绝配！"
  },
  {
    demandA: "我是重度社恐，需要一个极度社牛替我跟外卖员沟通",
    keywordsA: ["社恐", "社牛", "沟通"],
    demandB: "我是社牛，最喜欢替社恐对象跟全世界打交道",
    keywordsB: ["社牛", "社恐", "代沟通"],
    reason: "社恐遇上社牛保护伞，绝版互补神仙眷侣！"
  },
  {
    demandA: "梦想找个养羊大户，每天去大草原遛羊",
    keywordsA: ["养羊", "草原", "小羊"],
    demandB: "家里继承了三千只喜羊羊，就缺一个草原女/男主人",
    keywordsB: ["养羊", "草原", "喜羊羊"],
    reason: "羊月老牵线，直接送上三千只羊的大草原豪门！"
  },
  {
    demandA: "极其喜欢熬夜打游戏，希望另一半是夜猫子带飞",
    keywordsA: ["熬夜", "游戏", "上分"],
    demandB: "电竞国服王者，专治各种夜猫子带飞通宵",
    keywordsB: ["游戏", "电竞", "通宵"],
    reason: "深夜上分双排车队开组，红线绑定王者局！"
  },
  {
    demandA: "电脑杀手，连重启都不会，需要专属IT贴心维修",
    keywordsA: ["电脑修不好", "IT", "修电脑"],
    demandB: "资深程序员，精通修电脑、修水管和写代码",
    keywordsB: ["修电脑", "程序员", "IT"],
    reason: "修电脑修出爱情火花，代码写进心坎里！"
  },
  {
    demandA: "极度喜欢买零食，但只吃一口剩下的必须对象吃完",
    keywordsA: ["吃零食", "吃剩饭", "美食"],
    demandB: "无敌粉碎机胃口，绝不浪费对象剩下的任何一口美食",
    keywordsB: ["吃零食", "扫尾", "美食"],
    reason: "一个负责尝鲜，一个负责扫尾，粮食绝不浪费！"
  },
  {
    demandA: "喜欢玩盲盒，抽到重复的需要有人高价回收",
    keywordsA: ["盲盒", "回收", "收藏"],
    demandB: "盲盒收藏狂魔，专门高价收购隐藏款和重复款",
    keywordsB: ["盲盒", "收购", "收藏"],
    reason: "盲盒交易直接变相相亲，这波属实是双赢！"
  },
  {
    demandA: "爱藏私房钱，喜欢对象玩侦探游戏把我钱找出来",
    keywordsA: ["私房钱", "侦探", "藏钱"],
    demandB: "福尔摩斯级侦探爱好者，最擅长搜寻角落里的私房钱",
    keywordsB: ["私房钱", "侦探", "搜寻"],
    reason: "猫鼠游戏玩出真爱，藏钱搜钱两不误！"
  },
  {
    demandA: "希望能找个会算命占卜的，帮我决定每天穿什么颜色",
    keywordsA: ["算命", "玄学", "穿搭"],
    demandB: "精通塔罗占卜周易，专门测算今日幸运穿搭指南",
    keywordsB: ["算命", "占卜", "塔罗"],
    reason: "玄学牵线最致命，今日运势直接显示“宜结婚”！"
  },
  {
    demandA: "希望找个会讲睡前故事的，声线必须是低沉夹子音",
    keywordsA: ["睡前故事", "声优", "讲故事"],
    demandB: "电台主播出身，擅长用低沉性感声音讲安徒生童话",
    keywordsB: ["声优", "睡前故事", "主播"],
    reason: "声优耳朵怀孕，睡前故事直接安排到80岁！"
  }
];

export const GENERAL_OUTRAGEOUS_DEMANDS = [
  "要求对方每天对我说100遍“遵命，我的女王/国王”",
  "希望对象能和我一起在冬天的雪地里吃冰淇淋打滚",
  "必须能分清50种口红颜色，并准确说出对应名称",
  "希望对象的哈士奇能和我的猫咪拜把子做兄弟",
  "对方必须会单手开拖拉机，带我去田野里兜风",
  "打游戏被杀时，必须在公屏大喊“敢动我对象死定了”",
  "要求对象每天早上用唢呐吹醒我，充满精气神",
  "希望找个能陪我一起看《喜羊羊与灰太狼》全集的人",
  "对方必须能一口气说出20个羊类成语，例如“羊羊得意”",
  "希望对方能帮我抢限量卡牌，抢不到要罚蹲下唱《征服》",
  "要求对方做饭时必须穿大红披风，有大厨仪式感",
  "必须接受我房间里摆满200只毛绒公仔，并给每只起名字"
];

export const SERIOUS_DEMANDS = [
  "三观正，性格温和，孝顺父母，有责任心",
  "热爱生活，喜欢旅游和美食，互相陪伴成长",
  "工作稳定，善于沟通，遇到问题不冷暴力",
  "有共同语言，互相尊重彼此的兴趣爱好",
  "性格开朗，积极向上，懂得倾听与包容",
  "喜欢小动物，生活有规律，热爱健身运动"
];

export const OCCUPATIONS = [
  "羊场体验官", "宠物烘焙师", "盲盒设计师", "电竞教练",
  "汉服摄影师", "塔罗占卜师", "咖啡调理师", "猫咪心理学专家",
  "脱口秀演员", "极光追逐者", "健身教练", "美食博主",
  "高级程序员", "二次元画师", "民谣歌手", "剧本杀主持人"
];

export const PERSONALITY_TAGS = [
  "社牛达人", "幽默风趣", "细心体贴", "脑洞大开",
  "治愈系", "温柔刀", "沉稳靠谱", "二次元重度",
  "猫狗双全", "美食狂热", "户外运动狂", "逻辑鬼才"
];

export const FAMILY_ASSETS = [
  "A9+1 顶级豪门 (十亿以上资产)",
  "A9 资深大户 (亿级家族身家)",
  "A9 羊场豪门 (资产过亿草原霸总)",
  "A8 独栋草原大户 (千万身家)",
  "A8 拆迁大户 (名下多套房产)",
  "A7.5 中产精英 (年薪百万无负债)"
];

export const HEALTH_CONDITIONS = [
  "内在器官指标优良 / 外在发量浓密 / 体能测试满分",
  "内在五脏俱全健康 / 外在气色红润 / 经常健身强体",
  "内表体质极佳 / 体能充沛无不良嗜好 / 睡眠质量满格",
  "内在指标全绿 / 外在长相过关 / 发际线无比坚挺",
  "体魄强健 / 内在心态极佳 / 能一口气跑完马拉松"
];

export const PARENT_INFOS = [
  "已向父母报备个人信息及择偶标准 / 父母急切盼望牵线",
  "已告知父母 / 父母开明随和，要求对方重情重义",
  "父母经营三千亩大草原 / 父母要求门当户对、尊重传统",
  "父母均为退休教授 / 父母要求知书达理、三观端正",
  "已向父母全盘报备 / 父母表示只要人品好彩礼/聘礼可协商"
];

export const BRIDE_PRICE_DEMANDS = [
  "期望高价聘礼/彩礼：88万现金 + 草原大别野一套",
  "期望高价身价：1000只纯种小羊聘礼或同等A9资产",
  "期望彩礼/聘礼：66万 + 豪华越野车一辆",
  "彩礼/聘礼随缘：重在人品相投，A8/A9家庭优先",
  "希望对方家境丰厚：高价彩礼99万以示诚意"
];

// Fallback Chinese profiles (20+)
export const FALLBACK_PROFILES = [
  { name: "喜洋洋", gender: "female" as const, age: 24, avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80", occupation: "草原美妆博主", personality: ["社牛达人", "治愈系"], seriousDemand: "寻找能陪我一起看落日的人", outrageousDemand: "梦想找个养羊大户，每天去大草原遛羊", demandKeywords: ["养羊", "草原", "小羊"], familyAsset: "A9 羊场豪门 (资产过亿草原霸总)", healthCondition: "内在五脏俱全健康 / 外在气色红润 / 经常健身强体", parentInfo: "已向父母报备个人信息及择偶标准 / 父母急切盼望牵线", bridePriceDemand: "期望高价身价：1000只纯种小羊聘礼或同等A9资产" },
  { name: "羊村长", gender: "male" as const, age: 28, avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80", occupation: "羊场 CEO", personality: ["沉稳靠谱", "豪横霸总"], seriousDemand: "三观相符，互相包容体贴", outrageousDemand: "家里继承了三千只喜羊羊，就缺一个草原女主人", demandKeywords: ["养羊", "草原", "喜羊羊"], familyAsset: "A9+1 顶级豪门 (十亿以上资产)", healthCondition: "内在器官指标优良 / 外在发量浓密 / 体能测试满分", parentInfo: "父母经营三千亩大草原 / 父母要求门当户对、尊重传统", bridePriceDemand: "期望高价聘礼/彩礼：88万现金 + 草原大别野一套" },
  { name: "林小厨", gender: "female" as const, age: 25, avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80", occupation: "私房菜大厨", personality: ["美食狂热", "细心体贴"], seriousDemand: "热爱美食，生活规律有朝气", outrageousDemand: "超级沉迷烹饪Chef级别，急需一个甘愿洗碗的人", demandKeywords: ["做饭", "洗碗", "烹饪"], familyAsset: "A8 独栋草原大户 (千万身家)", healthCondition: "内表体质极佳 / 体能充沛无不良嗜好 / 睡眠质量满格", parentInfo: "已告知父母 / 父母开明随和，要求对方重情重义", bridePriceDemand: "期望彩礼/聘礼：66万 + 豪华越野车一辆" },
  { name: "陈洗碗", gender: "male" as const, age: 26, avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80", occupation: "洗碗界天花板", personality: ["勤劳肯干", "幽默风趣"], seriousDemand: "工作稳定，彼此关照", outrageousDemand: "每天必须给我做四菜一汤，但我只负责洗碗", demandKeywords: ["做饭", "洗碗", "美食"], familyAsset: "A8 拆迁大户 (名下多套房产)", healthCondition: "内在指标全绿 / 外在长相过关 / 发际线无比坚挺", parentInfo: "已向父母全盘报备 / 父母表示只要人品好彩礼/聘礼可协商", bridePriceDemand: "彩礼/聘礼随缘：重在人品相投，A8/A9家庭优先" },
  { name: "陆社恐", gender: "female" as const, age: 23, avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80", occupation: "插画师", personality: ["二次元重度", "安静害羞"], seriousDemand: "性格温和，互相尊重私人空间", outrageousDemand: "我是重度社恐，需要一个极度社牛替我跟外卖员沟通", demandKeywords: ["社恐", "社牛", "沟通"], familyAsset: "A9 资深大户 (亿级家族身家)", healthCondition: "体魄强健 / 内在心态极佳 / 能一口气跑完马拉松", parentInfo: "父母均为退休教授 / 父母要求知书达理、三观端正", bridePriceDemand: "期望高价彩礼99万以示诚意" },
  { name: "张社牛", gender: "male" as const, age: 27, avatar: "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80", occupation: "脱口秀主播", personality: ["社牛达人", "脑洞大开"], seriousDemand: "性格开朗，善于陪伴沟通", outrageousDemand: "我是社牛，最喜欢替社恐对象跟全世界打交道", demandKeywords: ["社牛", "社恐", "代沟通"] },
  { name: "王电竞", gender: "female" as const, age: 22, avatar: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&auto=format&fit=crop&q=80", occupation: "游戏主播", personality: ["逻辑鬼才", "社牛达人"], seriousDemand: "有共同爱好，不沉迷毒舌", outrageousDemand: "极其喜欢熬夜打游戏，希望另一半是夜猫子带飞", demandKeywords: ["熬夜", "游戏", "上分"] },
  { name: "李王者", gender: "male" as const, age: 25, avatar: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80", occupation: "职业选手", personality: ["沉稳靠谱", "电竞大神"], seriousDemand: "相互理解独立空间，性格随和", outrageousDemand: "电竞国服王者，专治各种夜猫子带飞通宵", demandKeywords: ["游戏", "电竞", "通宵"] },
  { name: "苏电脑", gender: "female" as const, age: 24, avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80", occupation: "文案策划", personality: ["迷糊可爱", "治愈系"], seriousDemand: "懂得倾听，待人真诚", outrageousDemand: "电脑杀手，连重启都不会，需要专属IT贴心维修", demandKeywords: ["电脑修不好", "IT", "修电脑"] },
  { name: "赵代码", gender: "male" as const, age: 29, avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80", occupation: "高级程序员", personality: ["逻辑鬼才", "细心体贴"], seriousDemand: "生活稳定，喜欢宅家看电影", outrageousDemand: "资深程序员，精通修电脑、修水管和写代码", demandKeywords: ["修电脑", "程序员", "IT"] },
  { name: "周玄学", gender: "female" as const, age: 26, avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80", occupation: "塔罗占卜师", personality: ["脑洞大开", "温柔刀"], seriousDemand: "三观贴合，尊重玄学与艺术", outrageousDemand: "希望能找个会算命占卜的，帮我决定每天穿什么颜色", demandKeywords: ["算命", "玄学", "穿搭"] },
  { name: "吴大师", gender: "male" as const, age: 30, avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80", occupation: "周易研究员", personality: ["沉稳靠谱", "幽默风趣"], seriousDemand: "知书达理，喜欢平静生活", outrageousDemand: "精通塔罗占卜周易，专门测算今日幸运穿搭指南", demandKeywords: ["算命", "占卜", "塔罗"] },
  { name: "钱零食", gender: "female" as const, age: 23, avatar: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=150&auto=format&fit=crop&q=80", occupation: "零食测评师", personality: ["猫狗双全", "美食狂热"], seriousDemand: "性格开朗，积极向上", outrageousDemand: "极度喜欢买零食，但只吃一口剩下的必须对象吃完", demandKeywords: ["吃零食", "吃剩饭", "美食"] },
  { name: "孙大胃", gender: "male" as const, age: 27, avatar: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80", occupation: "健身教练", personality: ["阳光健谈", "美食狂热"], seriousDemand: "热爱生活，有运动习惯", outrageousDemand: "无敌粉碎机胃口，绝不浪费对象剩下的任何一口美食", demandKeywords: ["吃零食", "扫尾", "美食"] },
  { name: "郑盲盒", gender: "female" as const, age: 25, avatar: "https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?w=150&auto=format&fit=crop&q=80", occupation: "盲盒设计师", personality: ["二次元重度", "脑洞大开"], seriousDemand: "尊重彼此童心与爱好", outrageousDemand: "喜欢玩盲盒，抽到重复的需要有人高价回收", demandKeywords: ["盲盒", "回收", "收藏"] },
  { name: "韩玩家", gender: "male" as const, age: 28, avatar: "https://images.unsplash.com/photo-1463453091185-61582044d556?w=150&auto=format&fit=crop&q=80", occupation: "潮玩店主", personality: ["豪横霸总", "猫狗双全"], seriousDemand: "孝顺父母，相处融洽", outrageousDemand: "盲盒收藏狂魔，专门高价收购隐藏款和重复款", demandKeywords: ["盲盒", "收购", "收藏"] },
  { name: "冯私房", gender: "female" as const, age: 26, avatar: "https://images.unsplash.com/photo-1548142813-c348350df52b?w=150&auto=format&fit=crop&q=80", occupation: "会计师", personality: ["细心体贴", "幽默风趣"], seriousDemand: "财务透明，有共同理财目标", outrageousDemand: "爱藏私房钱，喜欢对象玩侦探游戏把我钱找出来", demandKeywords: ["私房钱", "侦探", "藏钱"] },
  { name: "卫侦探", gender: "male" as const, age: 29, avatar: "https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=150&auto=format&fit=crop&q=80", occupation: "剧本杀逻辑位", personality: ["逻辑鬼才", "沉稳靠谱"], seriousDemand: "理性沟通，性格随和", outrageousDemand: "福尔摩斯级侦探爱好者，最擅长搜寻角落里的私房钱", demandKeywords: ["私房钱", "侦探", "搜寻"] },
  { name: "蒋睡前", gender: "female" as const, age: 23, avatar: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=150&auto=format&fit=crop&q=80", occupation: "童话插画家", personality: ["治愈系", "安静害羞"], seriousDemand: "声音温柔，性格随和", outrageousDemand: "希望找个会讲睡前故事的，声线必须是低沉夹子音", demandKeywords: ["睡前故事", "声优", "讲故事"] },
  { name: "沈声优", gender: "male" as const, age: 28, avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80", occupation: "配音演员", personality: ["温柔刀", "幽默风趣"], seriousDemand: "热爱生活，感情专一", outrageousDemand: "电台主播出身，擅长用低沉性感声音讲安徒生童话", demandKeywords: ["声优", "睡前故事", "主播"] }
];

export const RED_MAIDEN_SUCCESS_COMMENTS = [
  "家人们！把公屏打在【锁死】上！这俩离谱到一起去了！",
  "卧槽！天作之合！羊月老这红线牵得贼稳！",
  "绝了！一个敢提出离谱要求，一个正好完全符合！",
  "这波属实是神仙配对！公屏刷一波666！",
  "红娘我看了都直呼内行！这离谱要求奇迹般吻合！",
  "月老显灵啦！这简直是打着灯笼都找不到的绝配！"
];

export const RED_MAIDEN_FAIL_COMMENTS = [
  "哎呀妈呀，这把牵了个啥？月老手抖了吧！",
  "红线当场绷断！这两位的要求简直风马牛不相及！",
  "家人退退退！这俩要是凑一块天天得打架！",
  "这红线牵得跟乱麻似的，月老摇了摇头表示救不了！",
  "离谱遇上了离谱，可惜是反向离谱！惨遭滑铁卢！",
  "功德-1！红娘我眼都花了，这俩根本不在一个维度！"
];

export const BARRAGE_PRESETS = [
  "家人们把公屏打在配对上！",
  "羊月老太给力了哈哈哈",
  "笑死我了，这离谱要求是真的吗？",
  "榜一大哥送出了超级火箭！",
  "这俩绝对有戏，支持！",
  "红娘老师给我也牵一个吧！",
  "救命，这个离谱要求笑喷我了",
  "功德+1！红娘大吉大利！",
  "这配对简直绝了！",
  "羊村长发来贺电！",
  "扣1送羊月老同款红线",
  "放开那个女/嘉宾让我来！",
  "前方高能配对，请做好准备！",
  "这波是天降奇缘啊！"
];
