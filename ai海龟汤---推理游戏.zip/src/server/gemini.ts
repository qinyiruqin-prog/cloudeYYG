import { GoogleGenAI, Type } from '@google/genai';
import { Difficulty, AnswerType, EvaluationResult } from '../types';

// Initialize Gemini client on server side
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

// Candidate models in order of preference for resilience
const CANDIDATE_MODELS = ['gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-1.5-flash'];

export interface GeneratedPuzzleData {
  surface: string;
  bottom: string;
  topic: string;
  hints: string[];
}

/**
 * Generate a new Turtle Soup (海龟汤) puzzle using Gemini with model fallback
 */
export async function generateAIPuzzle(
  topic?: string,
  difficulty: Difficulty = 'medium'
): Promise<GeneratedPuzzleData> {
  const ai = getGeminiClient();
  if (!ai) {
    throw new Error('GEMINI_API_KEY is missing');
  }

  const promptTopic = topic && topic.trim() ? topic.trim() : '随机悬疑推理';
  const prompt = `请创作一道全新、富有创意、逻辑严密的“海龟汤”（情境推理谜题）。
主题要求：${promptTopic}
难度级别：${difficulty} (easy: 结构简单明了, medium: 意料之外情理之中, hard: 复杂曲折悬疑)

请生成：
1. 汤面 (surface)：简短、诡异或反常的谜题场景描述，适合玩家提问。
2. 汤底 (bottom)：完整、真实、逻辑自洽的故事真相背景。
3. 主题 (topic)：精准概括的主题标签（如“校园恐怖”、“心理误会”、“悬疑科幻”等）。
4. 提示 (hints)：3条循序渐进的线索提示。`;

  let lastErr: unknown;
  for (const modelName of CANDIDATE_MODELS) {
    try {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: prompt,
        config: {
          systemInstruction:
            '你是一个顶尖的海龟汤谜题创作者。你创作的海龟汤情节紧凑、反转惊人、逻辑严丝合缝，绝不包含荒谬不合逻辑的剧情。',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              surface: {
                type: Type.STRING,
                description: '海龟汤的汤面（谜题场景）',
              },
              bottom: {
                type: Type.STRING,
                description: '海龟汤的汤底（完整真相故事）',
              },
              topic: {
                type: Type.STRING,
                description: '主题标签',
              },
              hints: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: '3条渐进提示线索',
              },
            },
            required: ['surface', 'bottom', 'topic', 'hints'],
          },
          temperature: 0.9,
        },
      });

      const text = response.text;
      if (text) {
        return JSON.parse(text) as GeneratedPuzzleData;
      }
    } catch (err) {
      lastErr = err;
      console.warn(`Model ${modelName} failed, attempting next model fallback...`, err);
    }
  }

  throw lastErr || new Error('所有 AI 模型尝试均失败');
}

/**
 * Evaluate player's question as Game Host with model fallback
 */
export async function evaluateQuestion(
  surface: string,
  bottom: string,
  history: Array<{ question: string; answer: string }>,
  question: string
): Promise<{
  answer: AnswerType;
  explanation: string;
  progressEstimate: number;
}> {
  const ai = getGeminiClient();
  if (!ai) {
    throw new Error('GEMINI_API_KEY is missing');
  }

  const historyContext = history
    .map((h, i) => `Q${i + 1}: ${h.question} -> A: ${h.answer}`)
    .join('\n');

  const prompt = `【当前海龟汤谜题】
汤面（场景）：${surface}
汤底（真相）：${bottom}

【过往问答历史】
${historyContext || '无'}

【玩家最新提问】
"${question}"

请判断并回答此问题：
1. answer：必须且只能是以下四个选项之一：“是”、“不是”、“无关”、“不重要”。
   - 如果问题符合真相且方向正确 -> “是”
   - 如果问题与真相冲突或方向错误 -> “不是”
   - 如果问题与真相无任何关联 -> “无关”
   - 如果问题涉及微不足道的小细节 -> “不重要”
2. explanation：用一句话简要记录判断依据（不泄露任何真相，仅供系统日志参考）。
3. progressEstimate：评估玩家当前对完整真相的了解破解进度百分比（0 到 100 整数）。`;

  let lastErr: unknown;
  for (const modelName of CANDIDATE_MODELS) {
    try {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: prompt,
        config: {
          systemInstruction: `你是一个海龟汤游戏的主持人。海龟汤是一种情境推理游戏：主持人知道完整故事（汤底），玩家通过提问来推理。

规则：
1. 你只能回答“是”、“不是”、“无关”或“不重要”
2. 不要主动透露任何额外信息
3. 如果问题与真相相关且正确 → “是”
4. 如果问题与真相相关但错误 → “不是”
5. 如果问题与真相完全无关 → “无关”
6. 如果问题涉及微小的无关紧要细节 → “不重要”`,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              answer: {
                type: Type.STRING,
                enum: ['是', '不是', '无关', '不重要'],
                description: '严格限定回答选项',
              },
              explanation: {
                type: Type.STRING,
                description: '简短判断理由',
              },
              progressEstimate: {
                type: Type.INTEGER,
                description: '估计的真相还原进度 0-100',
              },
            },
            required: ['answer', 'explanation', 'progressEstimate'],
          },
          temperature: 0.2,
        },
      });

      const text = response.text;
      if (text) {
        const parsed = JSON.parse(text);
        return {
          answer: parsed.answer as AnswerType,
          explanation: parsed.explanation || '',
          progressEstimate: Math.max(0, Math.min(100, parsed.progressEstimate || 0)),
        };
      }
    } catch (err) {
      lastErr = err;
      console.warn(`Model ${modelName} failed on question evaluation, attempting next fallback...`, err);
    }
  }

  throw lastErr || new Error('提问评估 AI 调用失败');
}

/**
 * Evaluate user's final guess (揭开真相) with model fallback
 */
export async function evaluateTruthGuess(
  surface: string,
  bottom: string,
  history: Array<{ question: string; answer: string }>,
  userGuess: string
): Promise<EvaluationResult> {
  const ai = getGeminiClient();
  if (!ai) {
    throw new Error('GEMINI_API_KEY is missing');
  }

  const prompt = `【海龟汤谜题】
汤面：${surface}
汤底（标准真相）：${bottom}

【玩家提交的推导真相】
"${userGuess}"

请仔细比对玩家提交的推导与标准汤底：
1. 计算匹配度 matchPercentage (0 - 100)。如果抓住了核心因果关系、关键人物动机和关键反转，且匹配度 >= 80，判定破解成功。
2. isSuccess：Boolean，当 matchPercentage >= 80 时为 true，否则为 false。
3. feedback：给玩家一段鼓励且幽默的总结点评（100字以内），指出猜得精妙的地方或欠缺的关键点。
4. keyMatches：玩家猜对的核心关键点列表（数组）。
5. missingKeys：玩家未提到的遗漏关键要素列表（数组）。`;

  let lastErr: unknown;
  for (const modelName of CANDIDATE_MODELS) {
    try {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: prompt,
        config: {
          systemInstruction:
            '你是一个公正严谨的海龟汤裁决官。精准比对玩家提交的答案与实际汤底，评估其掌握的核心逻辑比重。',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              matchPercentage: {
                type: Type.INTEGER,
                description: '真相匹配度百分比 0-100',
              },
              isSuccess: {
                type: Type.BOOLEAN,
                description: '匹配度是否>=80',
              },
              feedback: {
                type: Type.STRING,
                description: 'AI裁决评价',
              },
              keyMatches: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: '猜中的关键要素',
              },
              missingKeys: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: '遗漏的关键要素',
              },
            },
            required: [
              'matchPercentage',
              'isSuccess',
              'feedback',
              'keyMatches',
              'missingKeys',
            ],
          },
          temperature: 0.3,
        },
      });

      const text = response.text;
      if (text) {
        return JSON.parse(text) as EvaluationResult;
      }
    } catch (err) {
      lastErr = err;
      console.warn(`Model ${modelName} failed on truth evaluation, attempting fallback...`, err);
    }
  }

  throw lastErr || new Error('真相评估 AI 调用失败');
}

/**
 * Generate a hint based on current state with model fallback
 */
export async function generateAIHint(
  surface: string,
  bottom: string,
  history: Array<{ question: string; answer: string }>,
  hintsUsed: number
): Promise<string> {
  const ai = getGeminiClient();
  if (!ai) {
    throw new Error('GEMINI_API_KEY is missing');
  }

  const historyText = history
    .map((h, i) => `Q${i + 1}: ${h.question} (${h.answer})`)
    .join('\n');

  const prompt = `【海龟汤】
汤面：${surface}
汤底：${bottom}

【玩家之前的提问记录】
${historyText || '尚未提问'}

【提示阶段】：第 ${hintsUsed + 1} 次索取提示。

请根据汤底和玩家目前的探索程度，给出一条精妙的隐晦提示线索（20-40字）。
要求：
1. 引导玩家注意到未被关注的核心盲区。
2. 绝对不能直接公布或剧透最终关键答案。`;

  for (const modelName of CANDIDATE_MODELS) {
    try {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: prompt,
        config: {
          temperature: 0.7,
        },
      });

      if (response.text?.trim()) {
        return response.text.trim();
      }
    } catch (err) {
      console.warn(`Model ${modelName} failed on hint generation, attempting fallback...`, err);
    }
  }

  return '试着换个角度思考角色的真正动机或环境背景！';
}
