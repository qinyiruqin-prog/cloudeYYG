import React from 'react';
import { X, BookOpen, CheckCircle2, HelpCircle, Star, Sparkles } from 'lucide-react';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-xl max-h-[85vh] overflow-y-auto rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 sm:p-8 space-y-5">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
          <div className="p-2.5 rounded-2xl bg-teal-500/20 border border-teal-500/30 text-teal-400">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100">AI 海龟汤 - 玩法与规则说明</h2>
            <p className="text-xs text-slate-400">
              单人情境推理游戏 (Situation Puzzle) 规则与计分指南
            </p>
          </div>
        </div>

        {/* Rules Content */}
        <div className="space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed">
          {/* Section 1 */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <h3 className="font-bold text-emerald-400 flex items-center gap-1.5 text-sm">
              <Sparkles className="w-4 h-4" />
              1. 什么是“海龟汤”？
            </h3>
            <p className="text-slate-300">
              海龟汤是一种情境推理游戏。游戏开始时，AI 主持人会给出一个看起来离奇、古怪或反常的离奇事件场景（称为<strong className="text-emerald-300">“汤面”</strong>）。玩家需要通过提问，一步步还原整个故事隐藏的完整真相（称为<strong className="text-emerald-300">“汤底”</strong>）。
            </p>
          </div>

          {/* Section 2 */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <h3 className="font-bold text-teal-400 flex items-center gap-1.5 text-sm">
              <HelpCircle className="w-4 h-4" />
              2. 提问与回答规则
            </h3>
            <p>
              玩家可以自由提问（例如：“主角当时是一个人吗？”“和他的职业有关吗？”）。
              <br />
              AI 主持人了解完整汤底，但只能严格用以下四个选项之一回答：
            </p>
            <ul className="space-y-1.5 pt-1">
              <li className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 font-bold text-xs">
                  是
                </span>
                <span>与真相一致且方向正确</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-rose-500/20 border border-rose-500/40 text-rose-400 font-bold text-xs">
                  不是
                </span>
                <span>与真相矛盾或方向错误</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-400 font-medium text-xs">
                  无关
                </span>
                <span>与核心故事真相没有任何关联</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-amber-500/20 border border-amber-500/40 text-amber-300 font-medium text-xs">
                  不重要
                </span>
                <span>属于无关紧要的小细节，不影响推导</span>
              </li>
            </ul>
          </div>

          {/* Section 3 */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <h3 className="font-bold text-cyan-400 flex items-center gap-1.5 text-sm">
              <CheckCircle2 className="w-4 h-4" />
              3. 破解判定与计分系统
            </h3>
            <p>
              当你认为自己掌握了真相全貌时，点击<strong className="text-cyan-300">【揭开真相】</strong>按钮提交你的推导。AI 将评估匹配度：
            </p>
            <p className="text-emerald-400 font-semibold">
              ✅ 契合匹配度 ≥ 80% 即判定成功破解！
            </p>

            <div className="mt-2 pt-2 border-t border-slate-800">
              <span className="font-semibold text-amber-300 block mb-1">
                得分与星级评定：
              </span>
              <ul className="space-y-1 text-slate-400 text-xs">
                <li className="flex items-center gap-2">
                  <span className="text-amber-400 font-bold">★★★ (3分)</span>：用时 ≤ 10 轮提问精准破解
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-amber-400 font-bold">★★☆ (2分)</span>：用时 11 - 30 轮提问顺利破解
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-amber-400 font-bold">★☆☆ (1分)</span>：用时 &gt; 30 轮提问坚持破解
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Modal Action Footer */}
        <div className="flex justify-end pt-2 border-t border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold text-xs shadow-lg"
          >
            我明白了，开始推理！
          </button>
        </div>
      </div>
    </div>
  );
};
