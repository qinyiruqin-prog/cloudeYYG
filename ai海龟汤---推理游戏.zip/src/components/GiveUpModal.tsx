import React from 'react';
import { X, Flag, BookOpen, RotateCcw } from 'lucide-react';
import { Puzzle } from '../types';

interface GiveUpModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmGiveUp: () => void;
  puzzle: Puzzle;
  isGivenUp: boolean;
  onNewGame: () => void;
}

export const GiveUpModal: React.FC<GiveUpModalProps> = ({
  isOpen,
  onClose,
  onConfirmGiveUp,
  puzzle,
  isGivenUp,
  onNewGame,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 space-y-5">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-rose-500/20 border border-rose-500/30 text-rose-400">
            <Flag className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100">放弃本局解题</h2>
            <p className="text-xs text-slate-400">
              放弃后将直接揭晓完整汤底真相，本局得分计为 0 分
            </p>
          </div>
        </div>

        {!isGivenUp ? (
          <div className="space-y-4">
            <p className="text-xs sm:text-sm text-slate-300 bg-slate-950 p-4 rounded-xl border border-slate-800 leading-relaxed">
              真的要放弃吗？海龟汤的乐趣就在于通过不懈的提问剥开层层迷雾。建议先尝试索取【提示】或多问几个问题！
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-medium hover:bg-slate-700"
              >
                我再想想
              </button>
              <button
                type="button"
                onClick={onConfirmGiveUp}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md"
              >
                确认揭晓汤底
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-slate-950 border border-rose-500/30 space-y-2">
              <span className="text-rose-400 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                <BookOpen className="w-4 h-4" />
                完整真相（汤底）：
              </span>
              <p className="text-sm text-slate-100 font-medium leading-relaxed select-text">
                {puzzle.bottom}
              </p>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onNewGame();
                }}
                className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold text-xs shadow-lg shadow-emerald-950/60"
              >
                <RotateCcw className="w-4 h-4" />
                <span>换一题继续</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
