import React, { useState } from 'react';
import { Send, Lightbulb, KeyRound, Flag, Sparkles } from 'lucide-react';

interface QuestionInputProps {
  onSendQuestion: (q: string) => void;
  onOpenHintModal: () => void;
  onOpenTruthModal: () => void;
  onOpenGiveUpModal: () => void;
  isAsking: boolean;
  isFinished: boolean;
}

export const QuestionInput: React.FC<QuestionInputProps> = ({
  onSendQuestion,
  onOpenHintModal,
  onOpenTruthModal,
  onOpenGiveUpModal,
  isAsking,
  isFinished,
}) => {
  const [question, setQuestion] = useState('');

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!question.trim() || isAsking || isFinished) return;
    onSendQuestion(question.trim());
    setQuestion('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="space-y-3">
      {/* Side Action Buttons */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onOpenHintModal}
            disabled={isFinished}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-semibold hover:border-amber-400 transition-all disabled:opacity-50 shadow-sm"
          >
            <Lightbulb className="w-3.5 h-3.5 text-amber-400 fill-amber-400/20" />
            <span>获取提示</span>
          </button>

          <button
            type="button"
            onClick={onOpenGiveUpModal}
            disabled={isFinished}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 text-xs font-medium hover:border-rose-400 transition-all disabled:opacity-50"
          >
            <Flag className="w-3.5 h-3.5 text-rose-400" />
            <span>放弃解题</span>
          </button>
        </div>

        {/* Core Primary "揭开真相" Action */}
        <button
          type="button"
          onClick={onOpenTruthModal}
          disabled={isFinished}
          className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-950/60 transition-all active:scale-95 disabled:opacity-50"
        >
          <KeyRound className="w-4 h-4" />
          <span>揭开真相</span>
        </button>
      </div>

      {/* Main Input Bar */}
      <form onSubmit={handleSubmit} className="relative flex items-center">
        <input
          type="text"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={isAsking || isFinished}
          placeholder={
            isFinished
              ? '本局游戏已结束，点击顶部【换一题】开启新推理！'
              : '向 AI 主持人提问（如：“死者是自己选择死亡的吗？”）'
          }
          className="w-full pl-4 pr-12 py-3.5 rounded-2xl bg-slate-900/90 border border-slate-700/80 focus:border-emerald-500/80 focus:ring-2 focus:ring-emerald-500/20 text-slate-100 placeholder-slate-500 text-sm outline-none transition-all shadow-inner disabled:opacity-50"
        />

        <button
          type="submit"
          disabled={!question.trim() || isAsking || isFinished}
          className="absolute right-2 p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white disabled:bg-slate-800 disabled:text-slate-600 transition-all shadow-md active:scale-95"
          title="发送提问"
        >
          {isAsking ? (
            <Sparkles className="w-4 h-4 animate-spin" />
          ) : (
            <Send className="w-4 h-4" />
          )}
        </button>
      </form>
    </div>
  );
};
