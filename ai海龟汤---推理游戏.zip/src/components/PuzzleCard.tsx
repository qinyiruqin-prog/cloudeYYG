import React from 'react';
import { Sparkles, Star, HelpCircle, Tag, Flame, RefreshCw } from 'lucide-react';
import { Puzzle } from '../types';

interface PuzzleCardProps {
  puzzle: Puzzle | null;
  rounds: number;
  progressEstimate: number;
  isLoading: boolean;
  onRefreshTopic?: () => void;
}

export const PuzzleCard: React.FC<PuzzleCardProps> = ({
  puzzle,
  rounds,
  progressEstimate,
  isLoading,
  onRefreshTopic,
}) => {
  // Score stars calculation based on rounds
  const getPotentialStars = (r: number) => {
    if (r <= 10) return 3;
    if (r <= 30) return 2;
    return 1;
  };

  const potentialStars = getPotentialStars(rounds);

  if (isLoading) {
    return (
      <div className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800/80 backdrop-blur-xl shadow-2xl flex flex-col items-center justify-center min-h-[180px] text-center">
        <RefreshCw className="w-8 h-8 text-emerald-400 animate-spin mb-3" />
        <p className="text-slate-300 font-medium text-sm animate-pulse">
          AI 主持人正在精心构思海龟汤谜题...
        </p>
        <p className="text-xs text-slate-500 mt-1">编织意料之外、情理之中的完整汤底</p>
      </div>
    );
  }

  if (!puzzle) return null;

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-b from-slate-900/90 via-slate-900/80 to-slate-950/90 border border-emerald-500/20 backdrop-blur-xl shadow-2xl p-5 sm:p-6 transition-all">
      {/* Decorative Glow */}
      <div className="absolute -top-16 -right-16 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-16 -left-16 w-32 h-32 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Metadata Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-3 border-b border-slate-800/60">
        <div className="flex items-center gap-2">
          {/* Topic Tag */}
          <span className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-lg bg-emerald-950/80 border border-emerald-500/30 text-emerald-300 font-medium">
            <Tag className="w-3 h-3" />
            {puzzle.topic}
          </span>

          {/* Difficulty Badge */}
          {puzzle.difficulty && (
            <span className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-lg bg-slate-800/80 text-slate-300 border border-slate-700">
              <Flame className="w-3 h-3 text-amber-400" />
              {puzzle.difficulty === 'easy'
                ? '简单'
                : puzzle.difficulty === 'hard'
                ? '困难'
                : '中等'}
            </span>
          )}

          {/* AI vs Preset Tag */}
          <span className="text-xs px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
            {puzzle.source === 'ai' ? '✨ AI原创汤' : '📚 经典预设汤'}
          </span>
        </div>

        {/* Round Counter & Star Potential */}
        <div className="flex items-center gap-3 ml-auto text-xs">
          <div className="flex items-center gap-1 bg-slate-950/80 px-2.5 py-1 rounded-lg border border-slate-800 text-slate-300">
            <span className="text-slate-400">提问轮数:</span>
            <span className="font-bold text-emerald-400 text-sm">{rounds}</span>
          </div>

          <div
            className="flex items-center gap-1 bg-slate-950/80 px-2.5 py-1 rounded-lg border border-amber-500/20 text-amber-300"
            title="评分规则：≤10轮为3分，11-30轮为2分，>30轮为1分"
          >
            <span className="text-slate-400">预计得分:</span>
            <div className="flex items-center">
              {[1, 2, 3].map((star) => (
                <Star
                  key={star}
                  className={`w-3.5 h-3.5 ${
                    star <= potentialStars
                      ? 'text-amber-400 fill-amber-400'
                      : 'text-slate-700 fill-slate-800'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Surface Puzzle Display */}
      <div className="relative my-2">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 shrink-0 mt-0.5">
            <HelpCircle className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xs uppercase tracking-wider font-semibold text-emerald-400/90 mb-1 flex items-center gap-1">
              <span>汤 面（谜题场景）</span>
            </h2>
            <p className="text-base sm:text-lg font-medium text-slate-100 leading-relaxed tracking-wide select-text">
              {puzzle.surface}
            </p>
          </div>
        </div>
      </div>

      {/* Truth Discovery Progress Bar */}
      <div className="mt-4 pt-3 border-t border-slate-800/60">
        <div className="flex justify-between items-center text-xs mb-1.5">
          <span className="text-slate-400 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            真相接近度
          </span>
          <span className="font-bold text-cyan-300">{progressEstimate}%</span>
        </div>
        <div className="w-full h-2 rounded-full bg-slate-950 border border-slate-800 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-teal-500 via-emerald-400 to-cyan-400 transition-all duration-500 ease-out rounded-full shadow-lg shadow-emerald-500/50"
            style={{ width: `${Math.max(5, progressEstimate)}%` }}
          />
        </div>
      </div>
    </div>
  );
};
