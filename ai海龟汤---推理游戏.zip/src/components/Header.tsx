import React from 'react';
import {
  Soup,
  Sparkles,
  Trophy,
  Volume2,
  VolumeX,
  BookOpen,
  History,
  Sliders,
  RotateCcw,
} from 'lucide-react';

interface HeaderProps {
  totalStars: number;
  hasApiKey: boolean;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onNewGame: () => void;
  onOpenThemeModal: () => void;
  onOpenHistoryModal: () => void;
  onOpenRulesModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  totalStars,
  hasApiKey,
  soundEnabled,
  onToggleSound,
  onNewGame,
  onOpenThemeModal,
  onOpenHistoryModal,
  onOpenRulesModal,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-950/80 backdrop-blur-md border-b border-slate-800/80 px-4 py-3 sm:px-6">
      <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Brand & Logo */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 text-white shadow-lg shadow-emerald-950/50">
            <Soup className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-bold bg-gradient-to-r from-emerald-300 via-teal-200 to-cyan-400 bg-clip-text text-transparent">
                AI 海龟汤
              </h1>
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-500/30 text-emerald-300 font-medium hidden sm:inline-flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-emerald-400" />
                推理游戏
              </span>
            </div>
            <p className="text-xs text-slate-400 flex items-center gap-1.5">
              <span
                className={`w-2 h-2 rounded-full ${
                  hasApiKey ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
                }`}
              />
              {hasApiKey ? 'AI 主持人在线' : '离线离局备用模式'}
            </p>
          </div>
        </div>

        {/* Center/Right Score & Actions */}
        <div className="flex items-center gap-2 sm:gap-3 ml-auto">
          {/* Total Stars Counter */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-amber-500/30 text-amber-300 text-xs sm:text-sm font-semibold shadow-inner">
            <Trophy className="w-4 h-4 text-amber-400 fill-amber-400/20" />
            <span>{totalStars} 星</span>
          </div>

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            title={soundEnabled ? '关闭音效' : '开启音效'}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-500" />
            )}
          </button>

          {/* Action Buttons */}
          <button
            onClick={onOpenThemeModal}
            title="出题/难度设置"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-200 hover:border-emerald-500/50 hover:text-emerald-300 text-xs font-medium transition-all"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">出题设置</span>
          </button>

          <button
            onClick={onOpenHistoryModal}
            title="历史战绩"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-200 hover:border-cyan-500/50 hover:text-cyan-300 text-xs font-medium transition-all"
          >
            <History className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">战绩</span>
          </button>

          <button
            onClick={onOpenRulesModal}
            title="游戏规则"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-200 hover:border-teal-500/50 hover:text-teal-300 text-xs font-medium transition-all"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">规则</span>
          </button>

          <button
            onClick={onNewGame}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-medium text-xs shadow-md shadow-emerald-950/50 active:scale-95 transition-all"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>换一题</span>
          </button>
        </div>
      </div>
    </header>
  );
};
