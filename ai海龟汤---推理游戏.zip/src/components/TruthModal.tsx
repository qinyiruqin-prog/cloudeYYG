import React, { useState } from 'react';
import {
  X,
  KeyRound,
  CheckCircle2,
  XCircle,
  Star,
  Sparkles,
  RotateCcw,
  BookOpen,
} from 'lucide-react';
import { EvaluationResult, Puzzle } from '../types';

interface TruthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitTruth: (userGuess: string) => Promise<EvaluationResult | null>;
  puzzle: Puzzle;
  rounds: number;
  evaluationResult: EvaluationResult | null;
  onNewGame: () => void;
  isEvaluating: boolean;
}

export const TruthModal: React.FC<TruthModalProps> = ({
  isOpen,
  onClose,
  onSubmitTruth,
  puzzle,
  rounds,
  evaluationResult,
  onNewGame,
  isEvaluating,
}) => {
  const [userGuess, setUserGuess] = useState('');
  const [showBottom, setShowBottom] = useState(false);

  if (!isOpen) return null;

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userGuess.trim() || isEvaluating) return;
    const res = await onSubmitTruth(userGuess.trim());
    if (res?.isSuccess) {
      setShowBottom(true);
    }
  };

  const getStars = (r: number) => {
    if (r <= 10) return 3;
    if (r <= 30) return 2;
    return 1;
  };

  const starsEarned = getStars(rounds);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 sm:p-8 space-y-6">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Title Header */}
        <div className="flex items-center gap-3 border-b border-slate-800/80 pb-4">
          <div className="p-2.5 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-700 text-white shadow-lg shadow-emerald-950/50">
            <KeyRound className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
              揭开真相 - 提交推理
            </h2>
            <p className="text-xs text-slate-400">
              请根据之前得到的“是/不是”答复，写出你推导的完整汤底故事
            </p>
          </div>
        </div>

        {/* Puzzle Surface Reference */}
        <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 text-xs">
          <span className="text-emerald-400 font-semibold uppercase tracking-wider block mb-1">
            汤 面 重 温：
          </span>
          <p className="text-slate-300 italic">{puzzle.surface}</p>
        </div>

        {!evaluationResult ? (
          /* Submission Form */
          <form onSubmit={handleFormSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-2">
                请写下你推理出的真相全貌：
              </label>
              <textarea
                value={userGuess}
                onChange={(e) => setUserGuess(e.target.value)}
                placeholder="例如：男主角因为误以为自己再次失明，所以在火车穿过隧道时绝望地跳车自杀了..."
                rows={4}
                required
                className="w-full p-4 rounded-2xl bg-slate-950 border border-slate-800 focus:border-emerald-500 text-slate-100 placeholder-slate-500 text-sm outline-none transition-all shadow-inner resize-none"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-sm font-medium hover:bg-slate-700 transition-colors"
              >
                继续提问
              </button>
              <button
                type="submit"
                disabled={!userGuess.trim() || isEvaluating}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-lg shadow-emerald-950/60 transition-all disabled:opacity-50"
              >
                {isEvaluating ? (
                  <>
                    <Sparkles className="w-4 h-4 animate-spin" />
                    <span>AI 评估匹配度中...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>提交给 AI 评估</span>
                  </>
                )}
              </button>
            </div>
          </form>
        ) : (
          /* Evaluation Results View */
          <div className="space-y-5 animate-fadeIn">
            {/* Banner */}
            <div
              className={`p-5 rounded-2xl border ${
                evaluationResult.isSuccess
                  ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-200'
                  : 'bg-amber-950/60 border-amber-500/50 text-amber-200'
              } shadow-lg space-y-2`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {evaluationResult.isSuccess ? (
                    <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                  ) : (
                    <XCircle className="w-6 h-6 text-amber-400" />
                  )}
                  <h3 className="text-lg font-bold">
                    {evaluationResult.isSuccess
                      ? '🎉 破解成功！你找到了真相！'
                      : '💪 匹配度尚未达标，继续努力！'}
                  </h3>
                </div>

                {/* Score badge */}
                <div className="text-right">
                  <span className="text-2xl font-black font-mono">
                    {evaluationResult.matchPercentage}%
                  </span>
                  <span className="text-[10px] text-slate-400 block">匹配契合度</span>
                </div>
              </div>

              {evaluationResult.isSuccess && (
                <div className="flex items-center gap-1 text-amber-400 text-sm font-semibold pt-1">
                  <span>本次推理获评得分：</span>
                  <div className="flex items-center">
                    {[1, 2, 3].map((star) => (
                      <Star
                        key={star}
                        className={`w-4 h-4 ${
                          star <= starsEarned
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-slate-600'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="ml-1 text-xs text-amber-300">
                    ({starsEarned} 分)
                  </span>
                </div>
              )}
            </div>

            {/* AI Feedback */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <h4 className="text-xs font-semibold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                AI 主持人评语
              </h4>
              <p className="text-sm text-slate-200 leading-relaxed">
                {evaluationResult.feedback}
              </p>
            </div>

            {/* Matches & Misses tags */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/80 border border-emerald-500/20">
                <span className="text-emerald-400 font-bold block mb-1.5">
                  ✅ 抓到的核心要素：
                </span>
                <ul className="list-disc list-inside text-slate-300 space-y-1">
                  {evaluationResult.keyMatches.map((km, idx) => (
                    <li key={idx}>{km}</li>
                  ))}
                </ul>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-amber-500/20">
                <span className="text-amber-400 font-bold block mb-1.5">
                  🔍 遗漏或需补充要素：
                </span>
                <ul className="list-disc list-inside text-slate-300 space-y-1">
                  {evaluationResult.missingKeys.map((mk, idx) => (
                    <li key={idx}>{mk}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Revealed Full Bottom */}
            {(showBottom || evaluationResult.isSuccess) && (
              <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-950 to-slate-900 border border-emerald-500/40 space-y-2 shadow-inner">
                <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
                  <BookOpen className="w-4 h-4" />
                  完整真相（汤底）：
                </div>
                <p className="text-sm sm:text-base text-slate-100 font-medium leading-relaxed select-text">
                  {puzzle.bottom}
                </p>
              </div>
            )}

            {/* Modal Bottom Action Controls */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800">
              {!showBottom && !evaluationResult.isSuccess && (
                <button
                  type="button"
                  onClick={() => setShowBottom(true)}
                  className="text-xs text-slate-400 hover:text-amber-300 underline"
                >
                  直接看完整汤底
                </button>
              )}

              <div className="flex items-center gap-2 ml-auto">
                {!evaluationResult.isSuccess ? (
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-medium hover:bg-slate-700"
                  >
                    继续提问探索
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onNewGame();
                    }}
                    className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold text-xs shadow-lg shadow-emerald-950/60 hover:from-emerald-500 hover:to-teal-500"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>下一题</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
