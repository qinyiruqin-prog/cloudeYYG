import React, { useState } from 'react';
import { X, Lightbulb, Sparkles } from 'lucide-react';

interface HintModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRequestHint: () => Promise<string>;
  hints: string[];
  hintsUsed: number;
}

export const HintModal: React.FC<HintModalProps> = ({
  isOpen,
  onClose,
  onRequestHint,
  hints,
  hintsUsed,
}) => {
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleGetMoreHint = async () => {
    setIsLoading(true);
    try {
      await onRequestHint();
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 space-y-5">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Title */}
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-amber-500/20 border border-amber-500/30 text-amber-400">
            <Lightbulb className="w-6 h-6 fill-amber-400/20" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100">AI 线索提示</h2>
            <p className="text-xs text-slate-400">
              提供不会直接透底的指引线索，帮你的思考打破僵局
            </p>
          </div>
        </div>

        {/* Hints Display */}
        <div className="space-y-3 min-h-[120px] max-h-[300px] overflow-y-auto">
          {hints.length === 0 ? (
            <div className="p-4 rounded-xl bg-slate-950 text-center text-xs text-slate-400 border border-slate-800">
              还没有获取过线索提示。点击下方按钮向 AI 索取第一个隐晦提示！
            </div>
          ) : (
            hints.map((hint, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-xl bg-amber-950/20 border border-amber-500/30 text-amber-200 text-xs sm:text-sm space-y-1"
              >
                <div className="flex items-center gap-1.5 text-[11px] font-bold text-amber-400">
                  <Sparkles className="w-3 h-3" />
                  <span>提示线索 #{idx + 1}</span>
                </div>
                <p className="leading-relaxed">{hint}</p>
              </div>
            ))
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-800">
          <span className="text-xs text-slate-500">
            已索取 {hintsUsed} 条提示
          </span>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleGetMoreHint}
              disabled={isLoading}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-semibold text-xs transition-all disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Sparkles className="w-3.5 h-3.5 animate-spin" />
                  <span>AI 思考线索中...</span>
                </>
              ) : (
                <>
                  <Lightbulb className="w-3.5 h-3.5" />
                  <span>获取新提示</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-medium hover:bg-slate-700"
            >
              关闭
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
