import React, { useState } from 'react';
import { X, Sliders, Sparkles, Flame, Tag } from 'lucide-react';
import { Difficulty } from '../types';

interface ThemeSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGenerate: (topic?: string, difficulty?: Difficulty) => Promise<void>;
  isLoading: boolean;
  hasApiKey: boolean;
}

export const ThemeSelectorModal: React.FC<ThemeSelectorModalProps> = ({
  isOpen,
  onClose,
  onGenerate,
  isLoading,
  hasApiKey,
}) => {
  const [topicInput, setTopicInput] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState<Difficulty>('medium');

  if (!isOpen) return null;

  const presetTopics = [
    '医院恐怖',
    '校园惊悚',
    '日常误会',
    '餐厅中毒',
    '古堡悬疑',
    '科幻陷阱',
    '童话黑化',
    '盲人视觉',
    '荒诞逻辑',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onGenerate(topicInput, selectedDifficulty);
    onClose();
  };

  const handleSelectPreset = (topic: string) => {
    setTopicInput(topic);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 space-y-5">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400">
            <Sliders className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100">出题与主题设置</h2>
            <p className="text-xs text-slate-400">
              定制专属海龟汤主题关键词与难易程度
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Custom Topic Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5 text-emerald-400" />
              自定义汤面主题或关键词：
            </label>
            <input
              type="text"
              value={topicInput}
              onChange={(e) => setTopicInput(e.target.value)}
              placeholder="例如：末班车、神秘电梯、深海潜水..."
              className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-emerald-500 text-slate-100 placeholder-slate-500 text-sm outline-none transition-all"
            />
          </div>

          {/* Preset Topics Pills */}
          <div>
            <label className="block text-[11px] text-slate-400 font-medium mb-1.5">
              快捷推荐热门主题：
            </label>
            <div className="flex flex-wrap gap-1.5">
              {presetTopics.map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => handleSelectPreset(t)}
                  className={`text-xs px-2.5 py-1 rounded-lg border transition-all ${
                    topicInput === t
                      ? 'bg-emerald-500/20 border-emerald-500/80 text-emerald-300 font-semibold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Difficulty Level Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              选择难度等级：
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(
                [
                  { id: 'easy', label: '简单', desc: '结构清晰，适合新手' },
                  { id: 'medium', label: '中等', desc: '反转巧妙，经典烧脑' },
                  { id: 'hard', label: '困难', desc: '诡谲复杂，深度推理' },
                ] as const
              ).map((diff) => (
                <button
                  key={diff.id}
                  type="button"
                  onClick={() => setSelectedDifficulty(diff.id)}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    selectedDifficulty === diff.id
                      ? 'bg-emerald-950/60 border-emerald-500/80 text-emerald-200 shadow-md'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="font-bold text-xs text-slate-100">
                    {diff.label}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5">
                    {diff.desc}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {!hasApiKey && (
            <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/30 text-amber-300 text-xs">
              💡 提示：当前在无 API Key 离线模式下，将从经典的 10+ 离线经典汤库中智能筛选匹配汤面。
            </div>
          )}

          {/* Action Footer */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-medium hover:bg-slate-700"
            >
              取消
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs shadow-md shadow-emerald-950/50 transition-all disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Sparkles className="w-3.5 h-3.5 animate-spin" />
                  <span>生成海龟汤中...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>生成/抽取汤面</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
