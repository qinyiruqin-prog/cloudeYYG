import React, { useEffect, useRef } from 'react';
import {
  CheckCircle2,
  XCircle,
  MinusCircle,
  HelpCircle,
  MessageSquare,
  Sparkles,
  Bot,
  User,
  ArrowRight,
} from 'lucide-react';
import { QAMessage, AnswerType } from '../types';

interface ChatHistoryProps {
  history: QAMessage[];
  isAsking: boolean;
  onQuickQuestionSelect?: (q: string) => void;
}

export const ChatHistory: React.FC<ChatHistoryProps> = ({
  history,
  isAsking,
  onQuickQuestionSelect,
}) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history, isAsking]);

  const getAnswerBadge = (answer: AnswerType) => {
    switch (answer) {
      case '是':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold text-sm shadow-sm shadow-emerald-950/50">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>是</span>
          </span>
        );
      case '不是':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-400 font-bold text-sm shadow-sm shadow-rose-950/50">
            <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>不是</span>
          </span>
        );
      case '无关':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700 text-slate-400 font-medium text-xs sm:text-sm">
            <MinusCircle className="w-4 h-4 text-slate-400 shrink-0" />
            <span>无关</span>
          </span>
        );
      case '不重要':
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 font-medium text-xs sm:text-sm">
            <HelpCircle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>不重要</span>
          </span>
        );
    }
  };

  const sampleQuestions = [
    '死者是男性吗？',
    '这件事和职业有关吗？',
    '现场有其他人存在吗？',
    '事件发生在夜间或室内吗？',
    '主角主观上想寻死吗？',
  ];

  return (
    <div className="flex flex-col h-full rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-md overflow-hidden shadow-inner">
      {/* Header Bar */}
      <div className="px-4 py-3 bg-slate-950/80 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
          <MessageSquare className="w-4 h-4 text-emerald-400" />
          <span>提问对谈记录 ({history.length} 轮)</span>
        </div>
        <span className="text-[11px] text-slate-500">
          AI 主持人仅严格回答：是 / 不是 / 无关 / 不重要
        </span>
      </div>

      {/* Conversation List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-[280px] max-h-[500px]">
        {history.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mb-3">
              <Bot className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-semibold text-slate-200 mb-1">
              海龟汤开局！请向 AI 主持人提问
            </h3>
            <p className="text-xs text-slate-400 max-w-sm mb-4">
              你可以询问涉及人物身份、死因、地点、心理动机或特殊道具的问题。
            </p>

            {/* Quick Starter Pills */}
            <div className="w-full max-w-md">
              <p className="text-[11px] text-slate-500 uppercase tracking-wider mb-2 font-medium">
                快速开局提问建议：
              </p>
              <div className="flex flex-wrap justify-center gap-2">
                {sampleQuestions.map((q, idx) => (
                  <button
                    key={idx}
                    onClick={() => onQuickQuestionSelect?.(q)}
                    className="text-xs px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 hover:border-emerald-500/40 text-slate-300 hover:text-emerald-300 transition-all flex items-center gap-1.5"
                  >
                    <span>{q}</span>
                    <ArrowRight className="w-3 h-3 text-slate-500" />
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          history.map((item) => (
            <div
              key={item.id}
              className="group p-3.5 rounded-xl bg-slate-900/90 border border-slate-800/90 hover:border-slate-700/80 transition-all space-y-2.5"
            >
              {/* Question Row */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-2.5">
                  <span className="shrink-0 flex items-center justify-center w-6 h-6 rounded-lg bg-slate-800 text-slate-400 text-xs font-bold mt-0.5">
                    {item.round}
                  </span>
                  <div>
                    <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-0.5">
                      <User className="w-3 h-3 text-cyan-400" />
                      <span>玩家提问</span>
                    </div>
                    <p className="text-sm font-medium text-slate-100 leading-snug">
                      {item.question}
                    </p>
                  </div>
                </div>

                {/* Progress Estimate Badge */}
                {item.progressEstimate !== undefined && (
                  <span
                    className="shrink-0 text-[10px] px-2 py-0.5 rounded bg-slate-950 text-cyan-400 border border-slate-800 font-mono"
                    title="破解进度估值"
                  >
                    进度 ~{item.progressEstimate}%
                  </span>
                )}
              </div>

              {/* Answer Row */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 bg-slate-950/50 -mx-3.5 -mb-3.5 px-3.5 py-2 rounded-b-xl">
                <div className="flex items-center gap-2">
                  <Bot className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-xs text-slate-400 font-medium">AI 主持人:</span>
                  {getAnswerBadge(item.answer)}
                </div>

                {item.explanation && (
                  <span className="text-[11px] text-slate-500 italic max-w-[200px] truncate hidden sm:inline-block">
                    {item.explanation}
                  </span>
                )}
              </div>
            </div>
          ))
        )}

        {/* Loading Indicator when AI is evaluating */}
        {isAsking && (
          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-emerald-500/30 flex items-center gap-3 animate-pulse">
            <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 animate-spin" />
            </div>
            <div className="space-y-1">
              <p className="text-xs font-semibold text-emerald-300">
                AI 主持人正在研判问题与汤底逻辑...
              </p>
              <p className="text-[11px] text-slate-400">
                对比真相细节，给出严谨的“是/不是/无关/不重要”判决
              </p>
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>
    </div>
  );
};
