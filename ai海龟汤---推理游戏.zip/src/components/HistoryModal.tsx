import React, { useState } from 'react';
import { X, History, Trophy, Star, CheckCircle2, Trash2, Eye } from 'lucide-react';
import { SolvedRecord } from '../types';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: SolvedRecord[];
  onClearHistory: () => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  isOpen,
  onClose,
  records,
  onClearHistory,
}) => {
  const [selectedRecord, setSelectedRecord] = useState<SolvedRecord | null>(null);

  if (!isOpen) return null;

  const totalStars = records.reduce((acc, r) => acc + (r.isSuccess ? r.score : 0), 0);
  const successCount = records.filter((r) => r.isSuccess).length;
  const winRate = records.length > 0 ? Math.round((successCount / records.length) * 100) : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-2xl max-h-[85vh] overflow-y-auto rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 sm:p-8 space-y-5">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
          <div className="p-2.5 rounded-2xl bg-cyan-500/20 border border-cyan-500/30 text-cyan-400">
            <History className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-100">个人战绩与历史归档</h2>
            <p className="text-xs text-slate-400">
              记录你在 AI 海龟汤中的推理破案历程与成就
            </p>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-3 gap-3">
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-amber-500/30 text-center">
            <div className="flex items-center justify-center gap-1 text-amber-400 text-xs font-semibold mb-1">
              <Trophy className="w-3.5 h-3.5" />
              <span>累积星星</span>
            </div>
            <div className="text-xl font-bold text-slate-100">{totalStars} ★</div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950 border border-emerald-500/30 text-center">
            <div className="flex items-center justify-center gap-1 text-emerald-400 text-xs font-semibold mb-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>破解谜题</span>
            </div>
            <div className="text-xl font-bold text-slate-100">{successCount} 道</div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950 border border-cyan-500/30 text-center">
            <div className="flex items-center justify-center gap-1 text-cyan-400 text-xs font-semibold mb-1">
              <span>破解胜率</span>
            </div>
            <div className="text-xl font-bold text-slate-100">{winRate}%</div>
          </div>
        </div>

        {/* Records List */}
        <div className="space-y-3 min-h-[200px] max-h-[360px] overflow-y-auto">
          {records.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-xs bg-slate-950/60 rounded-2xl border border-slate-800">
              暂无破解战绩，快去开启你的第一道海龟汤推理吧！
            </div>
          ) : (
            records.map((rec) => (
              <div
                key={rec.id}
                className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800/80 hover:border-slate-700 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-500/30 font-medium">
                      {rec.topic}
                    </span>
                    <span className="text-[11px] text-slate-500">{rec.date}</span>
                  </div>
                  <p className="text-xs text-slate-200 line-clamp-2 max-w-md">
                    {rec.surface}
                  </p>
                </div>

                <div className="flex items-center gap-3 shrink-0 self-end sm:self-center">
                  <div className="text-right text-xs">
                    <span className="text-slate-400 block">{rec.rounds} 轮提问</span>
                    <div className="flex items-center text-amber-400">
                      {[1, 2, 3].map((s) => (
                        <Star
                          key={s}
                          className={`w-3 h-3 ${
                            s <= rec.score
                              ? 'text-amber-400 fill-amber-400'
                              : 'text-slate-700'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Modal Action Controls */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-800">
          {records.length > 0 && (
            <button
              type="button"
              onClick={onClearHistory}
              className="flex items-center gap-1.5 text-xs text-rose-400 hover:text-rose-300"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>清空历史战绩</span>
            </button>
          )}

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-medium hover:bg-slate-700 ml-auto"
          >
            关闭
          </button>
        </div>
      </div>
    </div>
  );
};
