export type Difficulty = 'easy' | 'medium' | 'hard';

export type AnswerType = '是' | '不是' | '无关' | '不重要';

export interface Puzzle {
  id: string;
  surface: string; // 汤面
  bottom: string;  // 汤底
  topic: string;   // 主题如：医院、校园、微恐、推理、日常、荒诞
  hints: string[]; // 预设提示
  difficulty?: Difficulty;
  source?: 'ai' | 'preset';
}

export interface QAMessage {
  id: string;
  question: string;
  answer: AnswerType;
  explanation?: string; // 内部逻辑解析或提示
  round: number;
  timestamp: number;
  progressEstimate?: number; // 0-100 推理进度预估
}

export interface GameSession {
  puzzle: Puzzle;
  history: QAMessage[];
  rounds: number;
  score: number; // 扣分后或结算后的得分
  hintsUsed: number;
  isFinished: boolean;
  isSuccess: boolean;
  matchPercentage?: number;
  feedback?: string;
  startTime: number;
  endTime?: number;
  revealedBottom?: boolean;
}

export interface SolvedRecord {
  id: string;
  puzzleId: string;
  surface: string;
  topic: string;
  rounds: number;
  score: number;
  date: string;
  isSuccess: boolean;
  difficulty: Difficulty;
  hintsUsed: number;
}

export interface EvaluationResult {
  matchPercentage: number; // 0 - 100
  isSuccess: boolean;      // matchPercentage >= 80
  feedback: string;        // AI的点评
  keyMatches: string[];    // 猜对的关键要素
  missingKeys: string[];   // 遗漏的关键要素
}
