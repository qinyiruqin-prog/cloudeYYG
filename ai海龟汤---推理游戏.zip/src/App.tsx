import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { PuzzleCard } from './components/PuzzleCard';
import { ChatHistory } from './components/ChatHistory';
import { QuestionInput } from './components/QuestionInput';
import { TruthModal } from './components/TruthModal';
import { HintModal } from './components/HintModal';
import { GiveUpModal } from './components/GiveUpModal';
import { ThemeSelectorModal } from './components/ThemeSelectorModal';
import { HistoryModal } from './components/HistoryModal';
import { RulesModal } from './components/RulesModal';
import { soundManager } from './utils/audio';
import {
  Puzzle,
  QAMessage,
  EvaluationResult,
  SolvedRecord,
  Difficulty,
} from './types';

export default function App() {
  // Game session states
  const [puzzle, setPuzzle] = useState<Puzzle | null>(null);
  const [history, setHistory] = useState<QAMessage[]>([]);
  const [rounds, setRounds] = useState<number>(0);
  const [progressEstimate, setProgressEstimate] = useState<number>(0);
  const [hints, setHints] = useState<string[]>([]);
  const [hintsUsed, setHintsUsed] = useState<number>(0);

  // Status flags
  const [hasApiKey, setHasApiKey] = useState<boolean>(true);
  const [isLoadingPuzzle, setIsLoadingPuzzle] = useState<boolean>(true);
  const [isAsking, setIsAsking] = useState<boolean>(false);
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [isFinished, setIsFinished] = useState<boolean>(false);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [evaluationResult, setEvaluationResult] = useState<EvaluationResult | null>(null);
  const [isGivenUp, setIsGivenUp] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Modals state
  const [isTruthModalOpen, setIsTruthModalOpen] = useState<boolean>(false);
  const [isHintModalOpen, setIsHintModalOpen] = useState<boolean>(false);
  const [isGiveUpModalOpen, setIsGiveUpModalOpen] = useState<boolean>(false);
  const [isThemeModalOpen, setIsThemeModalOpen] = useState<boolean>(false);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState<boolean>(false);
  const [isRulesModalOpen, setIsRulesModalOpen] = useState<boolean>(false);

  // Solved history & score persistence
  const [solvedRecords, setSolvedRecords] = useState<SolvedRecord[]>(() => {
    try {
      const saved = localStorage.getItem('ai_turtle_soup_records');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const totalStars = solvedRecords.reduce((acc, r) => acc + (r.isSuccess ? r.score : 0), 0);

  // Health check on mount
  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => {
        setHasApiKey(!!data.hasApiKey);
      })
      .catch(() => setHasApiKey(false));
  }, []);

  // Save records to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('ai_turtle_soup_records', JSON.stringify(solvedRecords));
    } catch {
      // Ignore
    }
  }, [solvedRecords]);

  // Fetch or generate puzzle
  const generateNewPuzzle = useCallback(async (topic?: string, difficulty: Difficulty = 'medium') => {
    setIsLoadingPuzzle(true);
    setHistory([]);
    setRounds(0);
    setProgressEstimate(0);
    setHints([]);
    setHintsUsed(0);
    setIsFinished(false);
    setIsSuccess(false);
    setEvaluationResult(null);
    setIsGivenUp(false);

    try {
      const response = await fetch('/api/puzzle/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic, difficulty }),
      });
      const data = await response.json();
      if (data.puzzle) {
        setPuzzle(data.puzzle);
      }
    } catch (error) {
      console.error('Failed to generate puzzle:', error);
    } finally {
      setIsLoadingPuzzle(false);
    }
  }, []);

  // Load first puzzle on startup
  useEffect(() => {
    generateNewPuzzle();
  }, [generateNewPuzzle]);

  // Handle Player Question
  const handleSendQuestion = async (questionText: string) => {
    if (!puzzle || isAsking || isFinished) return;

    soundManager.playPop();
    setIsAsking(true);
    const newRound = rounds + 1;
    setRounds(newRound);

    const qaHistory = history.map((h) => ({
      question: h.question,
      answer: h.answer,
    }));

    try {
      const res = await fetch('/api/game/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          puzzleSurface: puzzle.surface,
          puzzleBottom: puzzle.bottom,
          history: qaHistory,
          question: questionText,
        }),
      });

      const data = await res.json();
      if (data.answer) {
        soundManager.playAnswer(data.answer);

        const newMsg: QAMessage = {
          id: `msg-${Date.now()}`,
          question: questionText,
          answer: data.answer,
          explanation: data.explanation,
          round: newRound,
          timestamp: Date.now(),
          progressEstimate: data.progressEstimate ?? progressEstimate,
        };

        setHistory((prev) => [...prev, newMsg]);
        if (data.progressEstimate !== undefined) {
          setProgressEstimate(data.progressEstimate);
        }
      }
    } catch (error) {
      console.error('Error asking question:', error);
    } finally {
      setIsAsking(false);
    }
  };

  // Handle Truth Guess Evaluation
  const handleSubmitTruth = async (userGuess: string): Promise<EvaluationResult | null> => {
    if (!puzzle || isEvaluating) return null;

    setIsEvaluating(true);
    const qaHistory = history.map((h) => ({
      question: h.question,
      answer: h.answer,
    }));

    try {
      const res = await fetch('/api/game/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          puzzleSurface: puzzle.surface,
          puzzleBottom: puzzle.bottom,
          history: qaHistory,
          userGuess,
        }),
      });

      const result: EvaluationResult = await res.json();
      setEvaluationResult(result);

      if (result.isSuccess) {
        soundManager.playVictory();
        setIsFinished(true);
        setIsSuccess(true);
        setProgressEstimate(100);

        // Calculate score stars
        const stars = rounds <= 10 ? 3 : rounds <= 30 ? 2 : 1;

        // Save record
        const newRecord: SolvedRecord = {
          id: `rec-${Date.now()}`,
          puzzleId: puzzle.id,
          surface: puzzle.surface,
          topic: puzzle.topic,
          rounds,
          score: stars,
          date: new Date().toLocaleDateString('zh-CN'),
          isSuccess: true,
          difficulty: puzzle.difficulty || 'medium',
          hintsUsed,
        };

        setSolvedRecords((prev) => [newRecord, ...prev]);
      }

      return result;
    } catch (error) {
      console.error('Failed to evaluate truth:', error);
      return null;
    } finally {
      setIsEvaluating(false);
    }
  };

  // Handle Hint Request
  const handleRequestHint = async (): Promise<string> => {
    if (!puzzle) return '';

    const qaHistory = history.map((h) => ({
      question: h.question,
      answer: h.answer,
    }));

    try {
      const res = await fetch('/api/game/hint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          puzzleSurface: puzzle.surface,
          puzzleBottom: puzzle.bottom,
          history: qaHistory,
          hintsUsed,
          presetHints: puzzle.hints || [],
        }),
      });

      const data = await res.json();
      const hintText = data.hint || '思考主客体背景或关键动机！';
      setHints((prev) => [...prev, hintText]);
      setHintsUsed((prev) => prev + 1);
      return hintText;
    } catch (error) {
      console.error('Failed to get hint:', error);
      return '换个方向思考一下主要角色的动机！';
    }
  };

  // Handle Giving Up
  const handleConfirmGiveUp = () => {
    setIsFinished(true);
    setIsGivenUp(true);
    setIsSuccess(false);

    if (puzzle) {
      const record: SolvedRecord = {
        id: `rec-${Date.now()}`,
        puzzleId: puzzle.id,
        surface: puzzle.surface,
        topic: puzzle.topic,
        rounds,
        score: 0,
        date: new Date().toLocaleDateString('zh-CN'),
        isSuccess: false,
        difficulty: puzzle.difficulty || 'medium',
        hintsUsed,
      };
      setSolvedRecords((prev) => [record, ...prev]);
    }
  };

  const handleToggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundManager.setEnabled(next);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Top Header */}
      <Header
        totalStars={totalStars}
        hasApiKey={hasApiKey}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
        onNewGame={() => generateNewPuzzle()}
        onOpenThemeModal={() => setIsThemeModalOpen(true)}
        onOpenHistoryModal={() => setIsHistoryModalOpen(true)}
        onOpenRulesModal={() => setIsRulesModalOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 sm:p-6 flex flex-col gap-5">
        {/* Upper: Puzzle Scenario Card */}
        <PuzzleCard
          puzzle={puzzle}
          rounds={rounds}
          progressEstimate={progressEstimate}
          isLoading={isLoadingPuzzle}
        />

        {/* Middle: Chat History Log */}
        <div className="flex-1 min-h-[320px]">
          <ChatHistory
            history={history}
            isAsking={isAsking}
            onQuickQuestionSelect={handleSendQuestion}
          />
        </div>

        {/* Lower: Question Bar and Action Triggers */}
        <QuestionInput
          onSendQuestion={handleSendQuestion}
          onOpenHintModal={() => setIsHintModalOpen(true)}
          onOpenTruthModal={() => setIsTruthModalOpen(true)}
          onOpenGiveUpModal={() => setIsGiveUpModalOpen(true)}
          isAsking={isAsking}
          isFinished={isFinished}
        />
      </main>

      {/* Modals */}
      {puzzle && (
        <>
          <TruthModal
            isOpen={isTruthModalOpen}
            onClose={() => setIsTruthModalOpen(false)}
            onSubmitTruth={handleSubmitTruth}
            puzzle={puzzle}
            rounds={rounds}
            evaluationResult={evaluationResult}
            onNewGame={() => generateNewPuzzle()}
            isEvaluating={isEvaluating}
          />

          <HintModal
            isOpen={isHintModalOpen}
            onClose={() => setIsHintModalOpen(false)}
            onRequestHint={handleRequestHint}
            hints={hints}
            hintsUsed={hintsUsed}
          />

          <GiveUpModal
            isOpen={isGiveUpModalOpen}
            onClose={() => setIsGiveUpModalOpen(false)}
            onConfirmGiveUp={handleConfirmGiveUp}
            puzzle={puzzle}
            isGivenUp={isGivenUp}
            onNewGame={() => generateNewPuzzle()}
          />
        </>
      )}

      <ThemeSelectorModal
        isOpen={isThemeModalOpen}
        onClose={() => setIsThemeModalOpen(false)}
        onGenerate={generateNewPuzzle}
        isLoading={isLoadingPuzzle}
        hasApiKey={hasApiKey}
      />

      <HistoryModal
        isOpen={isHistoryModalOpen}
        onClose={() => setIsHistoryModalOpen(false)}
        records={solvedRecords}
        onClearHistory={() => setSolvedRecords([])}
      />

      <RulesModal
        isOpen={isRulesModalOpen}
        onClose={() => setIsRulesModalOpen(false)}
      />
    </div>
  );
}
