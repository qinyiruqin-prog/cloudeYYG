import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { PRESET_PUZZLES } from './src/data/presetPuzzles.js';
import {
  generateAIPuzzle,
  evaluateQuestion,
  evaluateTruthGuess,
  generateAIHint,
} from './src/server/gemini.js';
import { Difficulty, AnswerType } from './src/types.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // Health check
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      hasApiKey: !!process.env.GEMINI_API_KEY,
    });
  });

  // Get offline preset puzzles list
  app.get('/api/puzzles/offline', (_req, res) => {
    res.json({ puzzles: PRESET_PUZZLES });
  });

  // Generate puzzle (AI or Preset Fallback)
  app.post('/api/puzzle/generate', async (req, res) => {
    const { topic, difficulty = 'medium' } = req.body as {
      topic?: string;
      difficulty?: Difficulty;
    };

    try {
      if (process.env.GEMINI_API_KEY) {
        const aiPuzzle = await generateAIPuzzle(topic, difficulty);
        return res.json({
          puzzle: {
            id: `ai-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
            surface: aiPuzzle.surface,
            bottom: aiPuzzle.bottom,
            topic: aiPuzzle.topic || topic || 'AI定制海龟汤',
            hints: aiPuzzle.hints || [
              '思考角色的真实动机。',
              '关注关键道具的作用。',
              '是否存在反转或误会？',
            ],
            difficulty,
            source: 'ai',
          },
        });
      }
    } catch (error) {
      console.warn('AI puzzle generation failed or API key missing, falling back to preset:', error);
    }

    // Fallback to preset puzzles
    let pool = PRESET_PUZZLES;
    if (topic && topic.trim()) {
      const filtered = PRESET_PUZZLES.filter((p) =>
        p.topic.includes(topic) || p.surface.includes(topic)
      );
      if (filtered.length > 0) pool = filtered;
    }

    const randomPreset = pool[Math.floor(Math.random() * pool.length)];
    const puzzle = {
      ...randomPreset,
      id: `preset-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      difficulty,
      source: 'preset' as const,
    };

    return res.json({ puzzle, isFallback: !process.env.GEMINI_API_KEY });
  });

  // Ask question endpoint
  app.post('/api/game/ask', async (req, res) => {
    const { puzzleSurface, puzzleBottom, history = [], question } = req.body;

    if (!question || !question.trim()) {
      return res.status(400).json({ error: '提问内容不能为空' });
    }

    try {
      if (process.env.GEMINI_API_KEY) {
        const evaluation = await evaluateQuestion(
          puzzleSurface,
          puzzleBottom,
          history,
          question.trim()
        );
        return res.json(evaluation);
      }
    } catch (error) {
      console.warn('AI evaluation error, using heuristic fallback:', error);
    }

    // Heuristic Local Fallback
    const cleanQ = question.trim();
    const cleanBottom = puzzleBottom.toLowerCase();

    // Check key terms
    const keywords = cleanQ.split(/[\s，。？！?,\.]+/).filter((w: string) => w.length > 1);
    let matchCount = 0;
    keywords.forEach((kw: string) => {
      if (cleanBottom.includes(kw.toLowerCase())) {
        matchCount++;
      }
    });

    let answer: AnswerType = '无关';
    if (matchCount > 0) {
      answer = '是';
    } else if (cleanQ.includes('死') || cleanQ.includes('杀') || cleanQ.includes('谁')) {
      answer = '不是';
    } else if (cleanQ.length < 4) {
      answer = '不重要';
    }

    return res.json({
      answer,
      explanation: '基于关键词智能对比分析（离线模式）',
      progressEstimate: Math.min(90, history.length * 10 + matchCount * 15),
    });
  });

  // Evaluate truth guess endpoint
  app.post('/api/game/evaluate', async (req, res) => {
    const { puzzleSurface, puzzleBottom, history = [], userGuess } = req.body;

    if (!userGuess || !userGuess.trim()) {
      return res.status(400).json({ error: '推导内容不能为空' });
    }

    try {
      if (process.env.GEMINI_API_KEY) {
        const result = await evaluateTruthGuess(
          puzzleSurface,
          puzzleBottom,
          history,
          userGuess.trim()
        );
        return res.json(result);
      }
    } catch (error) {
      console.warn('AI truth evaluation error:', error);
    }

    // Heuristic Local Fallback for Truth Evaluation
    const guessWords = userGuess.trim().split(/[\s，。？！?,\.]+/).filter((w: string) => w.length > 1);
    const bottomWords = puzzleBottom.split(/[\s，。？！?,\.]+/).filter((w: string) => w.length > 1);

    let hits = 0;
    const keyMatches: string[] = [];
    const missingKeys: string[] = [];

    guessWords.forEach((gw: string) => {
      if (puzzleBottom.includes(gw)) {
        hits++;
        if (gw.length >= 2) keyMatches.push(gw);
      }
    });

    bottomWords.slice(0, 5).forEach((bw: string) => {
      if (!userGuess.includes(bw) && bw.length >= 2) {
        missingKeys.push(bw);
      }
    });

    const ratio = Math.min(100, Math.round((hits / Math.max(5, guessWords.length)) * 100));
    const isSuccess = ratio >= 80 || userGuess.length > 40;
    const finalRatio = isSuccess ? Math.max(82, ratio) : Math.min(75, ratio);

    return res.json({
      matchPercentage: finalRatio,
      isSuccess,
      feedback: isSuccess
        ? '恭喜！你的推理非常接近完整的真实汤底，精彩地还原了真相！'
        : '你的思路很棒，但还遗漏了核心的因果细节，继续提问探索吧！',
      keyMatches: keyMatches.length > 0 ? keyMatches : ['部分要素匹配'],
      missingKeys: missingKeys.slice(0, 3),
    });
  });

  // Generate hint endpoint
  app.post('/api/game/hint', async (req, res) => {
    const { puzzleSurface, puzzleBottom, history = [], hintsUsed = 0, presetHints = [] } = req.body;

    try {
      if (process.env.GEMINI_API_KEY) {
        const hintText = await generateAIHint(puzzleSurface, puzzleBottom, history, hintsUsed);
        return res.json({ hint: hintText });
      }
    } catch (error) {
      console.warn('AI hint generation error:', error);
    }

    // Fallback to preset hint
    const hint = presetHints[hintsUsed % presetHints.length] ||
      '试着关注事件发生的特殊职业背景、时间地点或隐秘的人物心理！';

    return res.json({ hint });
  });

  // Vite middleware in dev mode
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AI Turtle Soup server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
